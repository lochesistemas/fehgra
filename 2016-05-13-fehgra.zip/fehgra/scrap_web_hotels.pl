#!/usr/bin/perl
use cPanelUserConfig;

use strict;
use warnings;

use Getopt::Std;
use CGI;
use Data::Dump;

use lib 'lib';
use URI::Escape;
use Scrapy;
use Text::Utils;

#-------------------------------------------------------------------------------
# get_opts :
# Description : Get the command line options provided by the user
#-------------------------------------------------------------------------------
sub get_opts {
  my $opt = {};
  getopts('h', $opt);

  #-------------------------------------------------------------------------------
  #print help if -h given
  if (exists($opt -> {"h"})) {
    print_help();
    exit;
  }
  #-------------------------------------------------------------------------------

  return $opt;
}

#-------------------------------------------------------------------------------
# get_args :
# Description : Get the command line arguments provided by the user
#-------------------------------------------------------------------------------
sub get_args {
  my $query = CGI -> new();
  my $args = $query -> Vars;
  $args = {};
  $args -> {city_id} = $ARGV[0] || die "city_id arg not provided!!!";
  $args -> {region_id} = uri_unescape($ARGV[1]) || die "region_id arg not provided!!!";
  $args -> {domain} = $ARGV[2] || die "domain arg not provided!!!";
  $args -> {user_url} = uri_unescape($ARGV[3]) || die "url arg not provided!!!";
  $args -> {query_id} = uri_unescape($ARGV[4]) || die "query_id arg not provided!!!";
  return $args;

  #-------------------------------------------------------------------------------
  # Check for invalid argument and show warnings if found
  my @validArgs = ("region_id", "city_id");
  my @allArgs = $query -> param();
  dd $query;
  my @invalidArgs;
  foreach my $curArg (@allArgs) {
    print STDERR "$curArg\n";
    push (@invalidArgs, $curArg) if ((grep ($curArg eq $_, @validArgs)) == 0);
  }

  warn ("Warning: Unknown argument '$_'") for (@invalidArgs);

  foreach my $curArg (@{validArgs}) {
    if (!defined($args -> {$curArg})) {
      die "$curArg argument not provided!!!";
    }
  }
  #-------------------------------------------------------------------------------

  return $args;
}

#-------------------------------------------------------------------------------
# print_help :
# Print help and exit
#-------------------------------------------------------------------------------
sub print_help {
my $helpTxt = <<EOF;

    +---------------------------------------------------------------------------------------------+
    |                     Help on $0
    +---------------------------------------------------------------------------------------------+
    | This script is used to scrape airbnb.com website
    |
    | Usages:
    |   perl <Path>/$0 <options> <arguments>
    |
    |   Note: Options must be provided before arguments.
    |
    | Options:
    |   -h : Print Help
    |
    | Arguments:
    |   user_id    : user_id of the user
    |   query_id   : query_id of the user
    |
    |   e.g. 1
    |   perl $0 -h
    |
    |   e.g. 2
    |   perl $0 
    |
    +---------------------------------------------------------------------------------------------+

EOF

  print ("$helpTxt\n");
  exit;
}
# Get the command line options and arguments and validate
my $in_opt = get_opts();
my $in_arg = get_args();

my $city_regions = CITY_REGIONS;
my $count = 1;
# while (my ($city_id, $region_id) = each %{$city_regions}) {
  #-------------------------------------------------------------------------------
  # Create hotels database from given websites - START
  #-------------------------------------------------------------------------------
my $scrapy = Scrapy -> new(
  userid => 'hoteles_w3',
  password => 'w3@123',
  database => 'hoteles_w3',
  table => 'web_hotels_tb',
  # region_id => $region_id,
  # city_id => $city_id,
  region_id => $in_arg -> {region_id},
  city_id => $in_arg -> {city_id},
  domain => $in_arg -> {domain},
  user_url => $in_arg -> {user_url},
  query_id => $in_arg -> {query_id},
);
$scrapy -> write_hotels;
  # print ("$region_id--$city_id\n");
  #-------------------------------------------------------------------------------
  # Create hotels database from given websites - END
  #-------------------------------------------------------------------------------

# }


