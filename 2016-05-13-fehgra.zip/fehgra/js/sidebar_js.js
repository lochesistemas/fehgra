// JavaScript Document
$(document).ready(function(){
	$(".myclass").click(function(){
		$(".myclass").parents("li").removeClass("active");
		$(this).parents("li").addClass("active");
	})						   
})