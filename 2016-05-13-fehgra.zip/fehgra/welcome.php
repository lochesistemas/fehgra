<?php include("include/connection.php"); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>FEHGRA</title>	

    <body class="skin-blue">
    <div class="wrapper">
	<?php include("include/header.php") ?>
	<script type="text/javascript" language="javascript" src="js/sidebar_js.js"></script>
    <?php include("include/top_header.php") ?>  
      
      <!-- Left side column. contains the logo and sidebar -->
      <aside class="main-sidebar">
        <!-- sidebar: style can be found in sidebar.less -->
        <?php include("include/sidebar.php") ?>
        <!-- /.sidebar -->
      </aside>
      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            <img src="logo.png">
 
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Inicio</a></li>
          </ol>
        </section>
        <!-- Main content -->
		<div class="row">
		<?php include("include/welcome_form.php") ?>
		 </div>	<!-- /.content -->
      </div><!-- /.content-wrapper -->
      <?php include("include/footer.php") ?>
    </div><!-- ./wrapper -->
	</body>
	
</html>