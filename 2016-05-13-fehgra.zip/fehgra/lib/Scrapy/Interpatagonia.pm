package Scrapy::Interpatagonia;
use strict;
use warnings;

use lib "lib";
use Scrapy::Mech::Try;
use Web::Scraper;
use Data::Dump;

sub new {
  my $class = shift;

  my %args = @_;

  my @valid = qw(hoteldb);

  foreach my $arg (@{valid}) {
    die "Argument $arg not defined!!" if (!defined($args{$arg}));
  }

  my $mech = Scrapy::Mech::Try -> new(
    agent => 'Mozilla/5.0 (X11; Linux i686; rv:12.0) Gecko/20100101 Firefox/12.0',
  );
  my $self = bless {
    mech => $mech,
    hoteldb => $args{hoteldb},
    url => $args{url},
  }, $class;
  return $self;

}

sub scrape_results {
  my $self = shift;

  my $mech = $self -> {mech};

  my $content = $mech -> content();

  my $p_datah = "//div[\@class='fr']/div[contains(\@class,'lista')]/a[\@class='hlink-wel']";
  
  my $s_datah = sub {
    my $he = shift;
    my $name = $he -> as_trimmed_text(extra_chars => '\p{Zs}\xB7\x{20AC}');
    my $href = $he -> attr('href');

    my $uri = URI -> new($href);
    my %query = $uri -> query_form();

    my $website = $query{cliente};

    if (defined($href) and $href =~ m{^/}) {
      $href = "http://www.welcomeargentina.com$href";
    }

    return {
      hotel_name => $name,
      website => $website,
      url => $href,
    };
  };

  my $scraper = scraper {
    process "$p_datah", "datas_h[]" => $s_datah;
  };

  my $scrape = $scraper -> scrape ($content);

  return [] if (!defined($scrape -> {datas_h}));
  return $scrape -> {datas_h};
}

sub lookup_hotel {
  my $self = shift;
  my $datas_h = shift;
  my $mech = $self -> {mech};

  foreach my $data_h (@{$datas_h}) {
    $self -> {hoteldb} -> write($data_h);
  }
}

sub write_hotels {
  my $self = shift;
  my $mech = $self -> {mech};

  my $url = $self -> {url};
  #my $url = "http://www.interpatagonia.com/bariloche/alojamientos_i.html";

  if (!defined($url)) {
    print ("[Skipping:Interpatagonia] url not defined for City_id=$self->{hoteldb}{city_id}\n");
    return;
  }

  $mech -> get($url);
  my $datas_h = $self -> scrape_results;

  $self -> lookup_hotel($datas_h);

}

1;

