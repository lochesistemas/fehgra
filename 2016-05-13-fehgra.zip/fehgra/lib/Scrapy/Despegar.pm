package Scrapy::Despegar;
use strict;
use warnings;

use lib "lib";
use Scrapy::Mech::Try;
use Web::Scraper;
use Text::Utils;

use Data::Dump;

sub new {
  my $class = shift;
  my %args = @_;

  my @valid = qw(hoteldb);

  foreach my $arg (@{valid}) {
    die "Argument $arg not defined!!" if (!defined($args{$arg}));
  }

  my $mech = Scrapy::Mech::Try -> new(
    agent => 'Mozilla/5.0 (X11; Linux i686; rv:12.0) Gecko/20100101 Firefox/12.0',
  );
  my $self = bless {
    mech => $mech,
    hoteldb => $args{hoteldb},
    url => $args{url},
  }, $class;
  return $self;
}

sub next_page {
  my $self = shift;
  my $page = shift;
  my $mech = $self -> {mech};

  $page += 1;

  if ($mech -> find_link(text => $page)) {
    $mech -> follow_link(text => $page);
    return 1;
  }
  else {
    return 0;
  }
}

sub scrape_results {
  my $self = shift;
  my $mech = $self -> {mech};

  my $content = $mech -> content();

  my $p_name = "//div[\@id='hotelResults']/div[\@name]";
  
  my $s_name = sub {
    my $he = shift;
    my $name = $he -> attr('name');
    my $link = $he -> attr('data-href');

    if (defined($link)) {
      $link = "http://www.despegar.com.ar$link";
    }

    return {hotel_name => $name, url => $link};
  };

  my $scraper = scraper {
    process "$p_name", "datas_h[]" => $s_name;
  };

  my $scrape = $scraper -> scrape ($content);

  return [] if (!defined($scrape -> {datas_h}));
  return $scrape -> {datas_h};
}

sub lookup_hotel {
  my $self = shift;
  my $datas_h = shift;
  my $mech = $self -> {mech};

  foreach my $data_h (@{$datas_h}) {
    $self -> {hoteldb} -> write($data_h);
  }
}

sub write_hotels {
  my $self = shift;
  my $mech = $self -> {mech};

  my $url = $self -> {url};
  #my $url = "http://www.despegar.com.ar/hoteles/hl/901/i1/hoteles-en-san+carlos+de+bariloche?standard=true";

  if (!defined($url)) {
    print ("[Skipping:Despegar] url not defined for City_id=$self->{hoteldb}{city_id}\n");
    return;
  }

  $mech -> get($url);
  my $datas_h = $self -> scrape_results;

  $self -> lookup_hotel($datas_h);

  my $page = 1;

  while ($self -> next_page($page++)) {
    $datas_h = $self -> scrape_results;
    $self -> lookup_hotel($datas_h);
  }

}


1;


