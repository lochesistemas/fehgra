package Scrapy::Booking;
use strict;
use warnings;

use Web::Scraper;
use Data::Dump;

use lib 'lib';
use Scrapy::Mech::Try;

sub new {
  my $class = shift;
  my %args = @_;

  my @valid = qw(hoteldb);

  foreach my $arg (@{valid}) {
    die "Argument $arg not defined!!" if (!defined($args{$arg}));
  }

  my $mech = Scrapy::Mech::Try -> new(
    agent => 'Mozilla/5.0 (X11; Linux i686; rv:12.0) Gecko/20100101 Firefox/12.0',
  );

  my $self = bless {
    mech => $mech,
    hoteldb => $args{hoteldb},
    url => $args{url},
  }, $class;

  return $self;
}

sub next_page {
  my $self = shift;
  my $page = shift;
  my $mech = $self -> {mech};

  $page += 1;

  if ($mech -> find_link(text => $page)) {

    my $uri = $mech -> uri();
    my %query = $uri -> query_form();
    $query{offset} = ($page - 1) * 15;
    $uri -> query_form(\%query);
    $mech -> get($uri);
    return 1;
  }
  else {
    return 0;
  }
}

sub scrape_results {
  my $self = shift;
  my $mech = $self -> {mech};

  my $content = $mech -> content();

  my $p_name = "//a[contains(\@class,'hotel_name_link')]";
  
  my $s_name = sub {
    my $he = shift;
    my $name = $he -> as_trimmed_text();
    my $link = $he -> attr('href');

    if (defined($link)) {
      $link = "http://www.booking.com$link";
    }

    return {hotel_name => $name, url => $link};
  };

  my $scraper = scraper {
    process "$p_name", "datas_h[]" => $s_name;
  };

  my $scrape = $scraper -> scrape ($content);

  return [] if (!defined($scrape -> {datas_h}));
  return $scrape -> {datas_h};
}

sub write_hotel {
  my $self = shift;
  my $datas_h = shift;
  my $mech = $self -> {mech};

  foreach my $data_h (@{$datas_h}) {
    $self -> {hoteldb} -> write($data_h);
  }
}

sub write_hotels {
  my $self = shift;

  my $mech = $self -> {mech};

  my $url = $self -> {url};

  if (!defined($url)) {
    print ("[Skipping:Booking] url not defined for City_id=$self->{hoteldb}{city_id}\n");
    return;
  }

  #my $url = "http://www.booking.com/searchresults.en-us.html?src=index&nflt=&ss_raw=san+carlos+de+bariloche%2C+&from_autocomplete=1&error_url=http%3A%2F%2Fwww.booking.com%2Findex.en-us.html%3Fsid%3Dd49fd13bbbfb4fb57c09ad1a0ce4a5ba%3Bdcid%3D1%3B&bb_asr=0&dcid=1&lang=en-us&sid=d49fd13bbbfb4fb57c09ad1a0ce4a5ba&si=ai%2Cco%2Cci%2Cre%2Cdi&ss=San+Carlos+de+Bariloche%2C+R%C3%ADo+Negro%2C+Argentina&idf=on&no_rooms=1&group_adults=2&group_children=0&dest_type=city&dest_id=-1012061&ac_pageview_id=7a41825d31db0074&ac_position=0&ac_langcode=en&ac_suggestion_list_length=5";

  $mech -> get($url);
  my $datas_h = $self -> scrape_results;

  $self -> write_hotel($datas_h);

  my $page = 1;

  while ($self -> next_page($page++)) {
    $datas_h = $self -> scrape_results;
    $self -> write_hotel($datas_h);
  }

}


1;



