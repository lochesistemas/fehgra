package DB::CityRegion;
use strict;
use warnings;
use DBI;

sub new {
  my $class = shift;

  my %args = @_;

  my $userid = $args{userid} || die "userid not defined!!!";
  my $password = $args{password} || die "password not defined!!!";
  my $database = $args{database} || die "Database not defined!!!";
  my $table = $args{table} || die "table not defined!!";

  my $driver = "mysql";
  my $dsn = "DBI:$driver:";

  my $dbh = DBI->connect($dsn, $userid, $password ) or die $DBI::errstr;

  $dbh->do("use $database");

  my @cols = qw(booking despegar interpatagonia);

  my $cols_str = join (",", @{cols});

  my $select_q = <<"MYSQL";

  select $cols_str from city where (id = ?)

MYSQL

  my $select_st = $dbh -> prepare($select_q);

  my $self = {
    database => $database,
    table => $table,
    cols => \@cols,
    dbh => $dbh,
    sth => $select_st,
  };
  $self = bless $self, $class;
  return $self;

}

#-------------------------------------------------------------------------------
# Sub : get_city_links
#-------------------------------------------------------------------------------
sub get_city_links {
  my $self = shift;
  my $args = shift;
  my $city_id = $args -> {city_id} || die "city_id not defined!!!";

  my $sth = $self -> {sth};
  my $cols = $self -> {cols};

  $sth->execute($city_id) or die $DBI::errstr;

  my @row = $sth->fetchrow_array;

  my %row_h;

  @row_h{@$cols} = @row;

  return \%row_h;
}


1;




