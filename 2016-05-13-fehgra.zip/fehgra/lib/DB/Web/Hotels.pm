#!/usr/bin/perl -w
use strict;
use warnings;

package DB::Web::Hotels;
use strict;
use warnings;
use DBI;
use Data::Dump;
use Text::Utils;


sub new {
  my $class = shift;

  my $args = shift;

  my $userid = $args -> {userid} || die "userid not defined!!!";
  my $password = $args -> {password};
  my $database = $args -> {database} || die "Database not defined!!!";
  my $table = $args -> {table} || die "table not defined!!";
  my $host_id = $args -> {host_id} || die "host_id not defined!!";
  my $region_id = $args -> {region_id} || die "region_id not defined!!";
  my $city_id = $args -> {city_id} || die "city_id not defined!!";
  my $query_id = $args -> {query_id} || die "query_id not defined!!";

  my $driver = "mysql";
  my $dsn = "DBI:$driver:";

  my $dbh = DBI->connect($dsn, $userid, $password ) or die $DBI::errstr;

  #-------------------------------------------------------------------------------
  # FIXME: REMOVE THIS DROP
  #$dbh->do("SET foreign_key_checks = 0");
  #$dbh->do("DROP DATABASE IF EXISTS $database");
  #-------------------------------------------------------------------------------

  $dbh->do("create database if not exists $database") or die "Cannot create database \n ";
  $dbh->do("use $database");

  my @headings = ('host_id', 'query_id', 'region_id', 'city_id', 'url', 'hotel_name', 'website', '__hotel__', '__website__', '__no_space_hotel__', '__sort_hotel__');

  my $self = {
    dbh => $dbh,
    sth => undef,
    database => $database,
    table => $table,
    host_id => $host_id,
    city_id => $city_id,
    region_id => $region_id,
    query_id => $query_id,
    headings => \@headings,
  };
  $self = bless $self, $class;

  $self -> create_table($table);

  my $cols_str = join (", ", @headings);

  my $sth = $dbh->prepare("INSERT INTO $table
                         ( $cols_str )
                          values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

  $self -> {sth} = $sth;

  return $self;
}

#-------------------------------------------------------------------------------
# Sub : create_table
#-------------------------------------------------------------------------------
sub create_table {
  my $self = shift;
  my $table = shift;

  my $dbh = $self -> {dbh};
  
  # $dbh->do("drop table if exists $table");

  my $query = <<"MYSQL";

  create table if not exists $table(
    id int not null auto_increment,
    host_id text not null,
    query_id datetime null,
    region_id int not null,
    city_id int not null,
    url longtext not null,
    hotel_name text not null,
    website text,

    __hotel__ text not null,
    __website__ text,
    __no_space_hotel__ text not null,
    __sort_hotel__ text not null,

    primary key (id)
  );

MYSQL

  $dbh->do($query) or die "Can't create table";

}

#-------------------------------------------------------------------------------
# Sub : update
#-------------------------------------------------------------------------------
sub update {
  my $self = shift;
  my $row_h = shift;
  my $dbh = $self -> {dbh};

  my @row = @{$row_h}{@{$self -> {headings}}};
  
  print ("Updating database: $row_h->{hotel_name}\n");

  my $sql = "UPDATE $self->{table}
             SET url=?
             WHERE hotel_name = ?";


  my $update_sth = $dbh->prepare($sql);
  $update_sth->execute($row_h->{url}, $row_h->{hotel_name}) or die $DBI::errstr;

}


#-------------------------------------------------------------------------------
# Sub : update_internal
#-------------------------------------------------------------------------------
sub update_internal {
  my $self = shift;
  my $row_h = shift;
  
  $row_h -> {host_id} = $self -> {host_id};
  $row_h -> {query_id} = $self -> {query_id};
  $row_h -> {region_id} = $self -> {region_id};
  $row_h -> {city_id} = $self -> {city_id};

  $row_h -> {__hotel__} = $row_h -> {hotel_name};

  $row_h -> {__hotel__} = lc(remove_multi_char($row_h -> {__hotel__}));
  $row_h -> {__hotel__} = remove_other($row_h -> {__hotel__});

  $row_h -> {__website__} = remove_multi_char($row_h -> {website});

  if (defined($row_h -> {__website__})) {
    $row_h -> {__website__} = lc($row_h -> {__website__});

    my($scheme, $authority, $path, $query, $fragment) = $row_h -> {__website__} =~ m|(?:([^:/?#]+)://)?(?:([^/?#]*))?([^?#]*)(?:\?([^#]*))?(?:#(.*))?|;

    $row_h -> {__website__} = $authority;
    $row_h -> {__website__} =~ s{www\.}{}g if (defined($row_h -> {__website__}));
  }

  $row_h -> {__no_space_hotel__} = $row_h -> {__hotel__};
  $row_h -> {__no_space_hotel__} =~ s/\s*//g;

  $row_h -> {__sort_hotel__} = join (" ", sort(split (/\s+/, $row_h -> {__hotel__})));

}

#-------------------------------------------------------------------------------
# Sub : write
#-------------------------------------------------------------------------------
sub write {
  my $self = shift;
  my $row_h = shift;
  my $dbh = $self -> {dbh};
  my $sth = $self -> {sth};

  $dbh->do("use $self->{database}");

  $self -> update_internal($row_h);
  dd $row_h;

  my @row = @{$row_h}{@{$self -> {headings}}};
  # print ("Adding database: $row_h->{hotel_name}\n");
  # $sth->execute(@row) or die $DBI::errstr;
    
  my $select_sth = $dbh->prepare("SELECT *
                            FROM $self->{table} 
                            WHERE hotel_name = ? and host_id = ? and region_id = ? and city_id = ? and query_id = ?");
  $select_sth->execute($row_h->{hotel_name}, $row_h->{host_id}, $row_h->{region_id}, $row_h->{city_id}, $row_h->{query_id}) or die $DBI::errstr;

  if ($select_sth->rows == 0) {
    print ("Adding database: $row_h->{hotel_name}\n");
    $sth->execute(@row) or die $DBI::errstr;
  }
  else {
    # my $ary_ref = $select_sth->fetchrow_arrayref;

    # if ($ary_ref->[2] eq $row_h -> {hotel_name}) {
    #   $self -> update($row_h);
    # }
  }
}


1;




