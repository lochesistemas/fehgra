package DB::Analyse::Hotels;
use strict;
use warnings;
use Data::Dump;
use Text::Utils;


#-------------------------------------------------------------------------------
# args *_db_h = {database => .., l_table => ..,}
#-------------------------------------------------------------------------------
sub new {
  my $class = shift;
  my %args = @_;

  my @valid = qw(userid web_db_h csv_db_h result_db_h);

  foreach my $varg (@{valid}) {
    die "$varg not defined!!" if (!defined($args{$varg}));
  }

  my $userid = $args{userid};
  my $password = $args{password};
  my $web_db_h = $args{web_db_h};
  my $csv_db_h = $args{csv_db_h};
  my $result_db_h = $args{result_db_h};

  my $drop_table = $result_db_h -> {drop_table};

  if (!defined($drop_table)) {
    $drop_table  = 0;
  }

  my $matching_criteria = <<"EXPRESSION";

      (csv_t.query_id = ?) and (web_t.query_id = ?) and (csv_t.user_id = $csv_db_h->{user_id}) and
      ((csv_t.__website__ is not null and csv_t.__website__ != '' and web_t.__website__ like concat('%', csv_t.__website__, '%')) or
      (web_t.__website__ is not null and web_t.__website__ != '' and csv_t.__website__ like concat('%', web_t.__website__, '%')) or
      (csv_t.__hotel__ is not null and csv_t.__hotel__ != '' and web_t.__hotel__ like concat('%', csv_t.__hotel__, '%')) or
      (web_t.__hotel__ is not null and web_t.__hotel__ != '' and csv_t.__hotel__ like concat('%', web_t.__hotel__, '%')) or
      (csv_t.__no_space_hotel__ is not null and csv_t.__no_space_hotel__ != '' and web_t.__no_space_hotel__ like concat('%', csv_t.__no_space_hotel__, '%')) or
      (web_t.__no_space_hotel__ is not null and web_t.__no_space_hotel__ != '' and csv_t.__no_space_hotel__ like concat('%', web_t.__no_space_hotel__, '%')) or
      (csv_t.__sort_hotel__ is not null and csv_t.__sort_hotel__ != '' and web_t.__sort_hotel__ like concat('%', csv_t.__sort_hotel__, '%')) or
      (web_t.__sort_hotel__ is not null and web_t.__sort_hotel__ != '' and csv_t.__sort_hotel__ like concat('%', web_t.__sort_hotel__, '%')))
EXPRESSION

  my $self = {
    userid => $userid,
    password => $password,
    web_db_h => $web_db_h,
    csv_db_h => $csv_db_h,
    result_db_h => $result_db_h,
    drop_table => $drop_table,
    no_legal_hotels => 0,
    no_illegal_hotels => 0,
    matching_criteria => $matching_criteria,
  };
  $self = bless $self, $class;

  $self -> connect_result_db();

  return $self;
}


#-------------------------------------------------------------------------------
# Sub : connect_result_db
#-------------------------------------------------------------------------------
sub connect_result_db {
  my $self = shift;

  my $driver = "mysql";
  my $dsn = "DBI:$driver:";

  my $dbh = DBI->connect($dsn, $self -> {userid}, $self -> {password}) or die $DBI::errstr;

  my $database = $self->{result_db_h}{database};

  #$dbh->do("create database if not exists $database") or die "Cannot create database \n ";

  $dbh->do("use $database");

  $self -> {result_db_h} {dbh} = $dbh;

  $self -> create_l_result_table($self -> {result_db_h} {l_table});
  $self -> create_i_result_table($self -> {result_db_h} {i_table});
  $self -> create_s_result_table($self -> {result_db_h} {s_table});

  $self -> get_region_id;
  $self -> get_city_id;
  $self -> get_user_type_id;

}

#-------------------------------------------------------------------------------
# Sub : get_region_id
#-------------------------------------------------------------------------------
sub get_region_id {
  my $self = shift;

  my $dbh = $self -> {result_db_h} {dbh};
  my $user_id = $self->{csv_db_h}->{user_id};

  my $sth = $dbh -> prepare("select city.rid from city, users where users.userid = ? and users.sid = city.id");
  $sth -> execute ($user_id) or die $DBI::errstr;

  #die "Region id not found!!" if ($sth -> rows == 0);

  my ($region_id) = $sth -> fetchrow_array;

  $self -> {region_id} = $region_id;
}

#-------------------------------------------------------------------------------
# Sub : get_city_id
#-------------------------------------------------------------------------------
sub get_city_id {
  my $self = shift;

  my $dbh = $self -> {result_db_h} {dbh};
  my $user_id = $self->{csv_db_h}->{user_id};

  my $sth = $dbh -> prepare("select sid from users where users.userid = ?");
  $sth -> execute ($user_id) or die $DBI::errstr;

  #die "City id not found!!" if ($sth -> rows == 0);

  my ($city_id) = $sth -> fetchrow_array;

  $self -> {city_id} = $city_id;
}

#-------------------------------------------------------------------------------
# Sub : get_user_type_id
#-------------------------------------------------------------------------------
sub get_user_type_id {
  my $self = shift;

  my $dbh = $self -> {result_db_h} {dbh};
  my $user_id = $self->{csv_db_h}->{user_id};

  my $sth = $dbh -> prepare("select typeid from users where userid = ?");
  $sth -> execute ($user_id) or die $DBI::errstr;

  #die "Usertype id not found!!" if ($sth -> rows == 0);

  my ($user_type_id) = $sth -> fetchrow_array;

  # $self -> {user_type_id} = $user_type_id;
  $self -> {user_type_id} = '1';
}

#-------------------------------------------------------------------------------
# Sub : create_s_result_table
#-------------------------------------------------------------------------------
sub create_s_result_table {
  my $self = shift;
  my $s_table = shift;

  my $dbh = $self -> {result_db_h} {dbh};

  if ($self -> {drop_table} == 1) {
    $dbh->do("drop table if exists $s_table");
  }
  
  my $query = <<"MYSQL";

  create table if not exists $s_table(
    user_id int,
    query_id datetime,
    no_illegal_hotels int,
    no_legal_hotels int,
    primary key (user_id, query_id)
  );

MYSQL
# foreign key (web_hotel_id) references $self->{web_db_h}->{s_table} (id),
# foreign key (csv_hotel_id) references $self->{csv_db_h}->{s_table} (id)

  $dbh->do($query) or die "Can't create table";

  my $insert_q = <<"MYSQL";

  insert into $s_table
         (user_id, query_id, no_illegal_hotels, no_legal_hotels)
         values (?, ?, ?, ?)
MYSQL

  my $sth = $dbh -> prepare($insert_q);

  $self -> {result_db_h} {"insert_s_sth"} = $sth;
}

#-------------------------------------------------------------------------------
# Sub : create_l_result_table
#-------------------------------------------------------------------------------
sub create_l_result_table {
  my $self = shift;
  my $l_table = shift;

  my $dbh = $self -> {result_db_h} {dbh};

  if ($self -> {drop_table} == 1) {
    $dbh->do("drop table if exists $l_table");
  }
  
  my $query = <<"MYSQL";

  create table if not exists $l_table(
    user_id int,
    web_hotel_id int,
    csv_hotel_id int,
    query_id datetime,
    primary key (user_id, web_hotel_id, csv_hotel_id, query_id)
  );

MYSQL
# foreign key (web_hotel_id) references $self->{web_db_h}->{l_table} (id),
# foreign key (csv_hotel_id) references $self->{csv_db_h}->{l_table} (id)

  $dbh->do($query) or die "Can't create table";

  my $insert_q = <<"MYSQL";

  insert into $l_table
         (user_id, web_hotel_id, csv_hotel_id, query_id)
         values (?, ?, ?, ?)
MYSQL

  my $sth = $dbh -> prepare($insert_q);

  $self -> {result_db_h} {"insert_l_sth"} = $sth;
}

#-------------------------------------------------------------------------------
# Sub : create_i_result_table
#-------------------------------------------------------------------------------
sub create_i_result_table {
  my $self = shift;
  my $i_table = shift;

  my $dbh = $self -> {result_db_h} {dbh};

  if ($self -> {drop_table} == 1) {
    $dbh->do("drop table if exists $i_table");
  }
  
  my $query = <<"MYSQL";

  create table if not exists $i_table(
    user_id int,
    web_hotel_id int,
    query_id datetime,
    primary key (user_id, web_hotel_id, query_id)
  );

MYSQL
# foreign key (web_hotel_id) references $self->{web_db_h}->{i_table} (id),
# foreign key (csv_hotel_id) references $self->{csv_db_h}->{i_table} (id)

  $dbh->do($query) or die "Can't create table";

  my $insert_q = <<"MYSQL";

  insert into $i_table
         (user_id, web_hotel_id, query_id)
         values (?, ?, ?)
MYSQL

  my $sth = $dbh -> prepare($insert_q);

  $self -> {result_db_h} {"insert_i_sth"} = $sth;
}

#-------------------------------------------------------------------------------
# Sub : analyse_legal
#-------------------------------------------------------------------------------
sub analyse_legal {
  my $self = shift;
  my $dbh = $self -> {result_db_h} -> {dbh};

  my $select_q = <<"MYSQL";

  select csv_t.user_id, web_t.id, csv_t.id, csv_t.query_id, web_t.city_id, web_t.region_id from 
    $self->{web_db_h}->{table} web_t,
    $self->{csv_db_h}->{table} csv_t where
    $self->{matching_criteria}
MYSQL

  my $select_st = $dbh -> prepare($select_q);
  $select_st->execute($self -> {csv_db_h}{query_id}, $self -> {csv_db_h}{query_id}) or die $DBI::errstr;

  my $insert_l_sth = $self -> {result_db_h} -> {insert_l_sth};

  print ("legal hotels\n");

  while (my @row = $select_st->fetchrow_array) {

    my $w_region_id = pop (@{row});
    my $w_city_id = pop (@{row});

    if (defined($self -> {user_type_id})) {
      if ($self -> {user_type_id} == CITY_USER) {
        if ($w_city_id == $self -> {city_id}) {
          dd \@row;

          $self -> {no_legal_hotels}++;
          $insert_l_sth -> execute(@row) or die $DBI::errstr;
        }
      }
      elsif ($self -> {user_type_id} == REGIONAL_USER) {
        if ($w_region_id == $self -> {region_id}) {
          $self -> {no_legal_hotels}++;
          $insert_l_sth -> execute(@row) or die $DBI::errstr;
        }
      }
      elsif ($self -> {user_type_id} == NATIONAL_USER) {
        $self -> {no_legal_hotels}++;
        $insert_l_sth -> execute(@row) or die $DBI::errstr;
      }
    }
  }
}

#-------------------------------------------------------------------------------
# Sub : analyse_illegal
# Perform analyse_legal first for this sub to work
#-------------------------------------------------------------------------------
sub analyse_illegal {
  my $self = shift;
  my $dbh = $self -> {result_db_h} -> {dbh};
  my $legal_t = $self -> {result_db_h} -> {l_table};
  my $illegal_t = $self -> {result_db_h} -> {i_table};

  my $select_q = <<"MYSQL";

  select distinct csv_t.user_id, web_t.id, csv_t.query_id, web_t.city_id, web_t.region_id  from 
    $self->{web_db_h}->{table} as web_t,
    $self->{csv_db_h}->{table} as csv_t
    where (csv_t.query_id = ?) and (web_t.query_id = ?) and (web_t.id not in (select legal_t.web_hotel_id from $legal_t as legal_t))
MYSQL

  my $select_st = $dbh -> prepare($select_q);
  $select_st->execute($self -> {csv_db_h}{query_id}, $self -> {csv_db_h}{query_id}) or die $DBI::errstr;

  my $insert_i_sth = $self -> {result_db_h} -> {insert_i_sth};

  print ("Illegal hotels\n");
  while (my @row = $select_st->fetchrow_array) {

    my $w_region_id = pop (@{row});
    my $w_city_id = pop (@{row});

    if (defined($self -> {user_type_id})) {
      if ($self -> {user_type_id} == CITY_USER) {
        if (defined($self -> {city_id}) and $w_city_id == $self -> {city_id}) {
          dd \@row;

          $self -> {no_illegal_hotels}++;
          $insert_i_sth -> execute(@row) or die $DBI::errstr;
        }
      }
      elsif ($self -> {user_type_id} == REGIONAL_USER) {
        if (defined($self -> {region_id}) and $w_region_id == $self -> {region_id}) {
          $self -> {no_illegal_hotels}++;
          $insert_i_sth -> execute(@row) or die $DBI::errstr;
        }
      }
      elsif ($self -> {user_type_id} == NATIONAL_USER) {
        $self -> {no_illegal_hotels}++;
        $insert_i_sth -> execute(@row) or die $DBI::errstr;
      }
    }

  }
}

#-------------------------------------------------------------------------------
# Sub : analyse_result_summary
#-------------------------------------------------------------------------------
sub analyse_result_summary {
  my $self = shift;
  my $dbh = $self -> {result_db_h} -> {dbh};
  my $illegal_t = $self -> {result_db_h} -> {i_table};

  my @row = ($self -> {csv_db_h}{user_id}, $self -> {csv_db_h}{query_id}, $self -> {no_illegal_hotels}, $self -> {no_legal_hotels});

  my $insert_s_sth = $self -> {result_db_h} -> {insert_s_sth};

  $insert_s_sth -> execute(@row) or die $DBI::errstr;
}

#-------------------------------------------------------------------------------
# Sub : analyse_all
#-------------------------------------------------------------------------------
sub analyse_all {
  my $self = shift;

  $self -> analyse_legal;

  $self -> analyse_illegal;

  $self -> analyse_result_summary 
  
}


1;












