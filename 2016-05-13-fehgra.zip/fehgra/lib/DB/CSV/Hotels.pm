#!/usr/bin/perl -w
use strict;
use warnings;

package DB::CSV::Hotels;
use strict;
use warnings;
use Data::Dump;
use Text::Utils;
use DBI;

sub new {
  my $class = shift;
  my %args = @_;

  my $userid = $args{userid} || die "userid not defined!!!";
  my $database = $args{database} || die "Database not defined!!!";
  my $table = $args{table} || die "table not defined!!";
  my $user_id = $args{user_id} || die "user_id not provided!!";
  my $query_id = $args{query_id} || die "query_id not provided!!";

  my $password = $args{password};
  my $drop_table = $args{drop_table};

  if (!defined($drop_table)) {
    $drop_table = 0;
  }

  my $driver = "mysql";
  my $dsn = "DBI:$driver:";

  my $dbh = DBI->connect($dsn, $userid, $password ) or die $DBI::errstr;

  #-------------------------------------------------------------------------------
  # FIXME: REMOVE THIS DROP
  #$dbh->do("DROP DATABASE IF EXISTS $database");
  #-------------------------------------------------------------------------------

  $dbh->do("create database if not exists $database");

  $dbh->do("use $database");

  my $self = {
    dbh => $dbh,
    sth => undef,
    table => $table,
    user_id => $user_id,
    query_id => $query_id,
    drop_table => $drop_table,
    cols => ['user_id', 'query_id', 'hotel_name', 'street', 'street_no', 'phone', 'email', 'website', '__hotel__', '__website__', '__no_space_hotel__', '__sort_hotel__'],
  };
  $self = bless $self, $class;

  $self -> create_table($table);

  my $cols = join (", ", @{$self->{cols}});

  my $sth = $dbh->prepare("INSERT INTO $table
                         ( $cols )
                          values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

  $self -> {sth} = $sth;

  return $self;

}

#-------------------------------------------------------------------------------
# Sub : create_table
#-------------------------------------------------------------------------------
sub create_table {
  my $self = shift;
  my $table = shift;

  my $dbh = $self -> {dbh};
  
  if ($self -> {drop_table} == 1) {
    $dbh->do("drop table if exists $table");
  }

  my $query = <<"MYSQL";

  create table if not exists $table(
    id int not null auto_increment primary key,
    user_id int,
    query_id datetime,
    hotel_name text not null,
    street text,
    street_no int,
    phone text,
    email text,
    website text,

    __hotel__ text not null,
    __website__ text,
    __no_space_hotel__ text not null,
    __sort_hotel__ text not null
  );

MYSQL

  $dbh->do($query) or die "Can't create table";
}


#-------------------------------------------------------------------------------
# Sub : update_internal
#-------------------------------------------------------------------------------
sub update_internal {
  my $self = shift;
  my $row_h = shift;
  
  $row_h -> {user_id} = $self -> {user_id};
  $row_h -> {query_id} = $self -> {query_id};

  $row_h -> {__hotel__} = $row_h -> {hotel_name};

  $row_h -> {__hotel__} = lc(remove_multi_char($row_h -> {__hotel__}));
  $row_h -> {__hotel__} = remove_other($row_h -> {__hotel__});

  $row_h -> {__website__} = remove_multi_char($row_h -> {website});

  if (defined($row_h -> {__website__})) {
    $row_h -> {__website__} = lc($row_h -> {__website__});

    my($scheme, $authority, $path, $query, $fragment) = $row_h -> {__website__} =~ m|(?:([^:/?#]+)://)?(?:([^/?#]*))?([^?#]*)(?:\?([^#]*))?(?:#(.*))?|;

    $row_h -> {__website__} = $authority;
    $row_h -> {__website__} =~ s{www\.}{}g if (defined($row_h -> {__website__}));
  }

  $row_h -> {__no_space_hotel__} = $row_h -> {__hotel__};
  $row_h -> {__no_space_hotel__} =~ s/\s*//g;

  $row_h -> {__sort_hotel__} = join (" ", sort(split (/\s+/, $row_h -> {__hotel__})));

}

#-------------------------------------------------------------------------------
# Sub : write
#-------------------------------------------------------------------------------
sub write {
  my $self = shift;
  my $row_a = shift;
  my $dbh = $self -> {dbh};
  my $sth = $self -> {sth};

  my $row_h = {};
  for (my $idx = 0; $idx < @$row_a; $idx++) {
    $row_h -> {$self -> {cols} [$idx + 2]} = $row_a -> [$idx]
  }

  $self -> update_internal ($row_h);

  dd $row_h;

  my @row = @{$row_h}{@{$self -> {cols}}};
  print ("Adding database: $row[0]\n");
  $sth->execute(@row) or die $DBI::errstr;
}


1;



