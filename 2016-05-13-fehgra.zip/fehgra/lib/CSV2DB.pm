#-------------------------------------------------------------------------------
# CSV Headings
# Name,Street,StreetNo,Phone,E Mail,Web
#-------------------------------------------------------------------------------

package CSV2DB;
use strict;
use warnings;
use Data::Dump;

use lib 'lib';

use CSV::Reader;
use DB::CSV::Hotels;

sub new {
  my $class = shift;

  my %args = @_;
  my $csv_file = $args{csv_file} || die "csv_file not provided!!";

  my $userid = $args{userid} || die "userid not defined!!!";
  my $database = $args{database} || die "Database not defined!!!";
  my $table = $args{table} || die "table not defined!!";
  my $user_id = $args{user_id} || die "user_id not provided!!";
  my $query_id = $args{query_id} || die "query_id not defined!!!";

  my $password = $args{password};

  my $drop_table = $args{drop_table};

  if (!defined($drop_table)) {
    $drop_table = 0;
  }

  my $csv_reader = CSV::Reader -> new(csv_file => $csv_file);

  my $csv_hoteldb = DB::CSV::Hotels -> new(
    userid => $userid,
    password => $password,
    database => $database,
    table => $table,
    user_id => $user_id,
    query_id => $query_id,
    drop_table => $drop_table,
  );

  my $self = {
    csv_reader => $csv_reader,
    csv_hoteldb => $csv_hoteldb,
  };
  $self = bless $self, $class;
  return $self;
}

#-------------------------------------------------------------------------------
# Sub : convert
#-------------------------------------------------------------------------------
sub convert {
  my $self = shift;
  my $csv_reader = $self -> {csv_reader};
  my $csv_hoteldb = $self -> {csv_hoteldb};

  while (!$csv_reader -> eof()) {

    my $row_a =  $csv_reader -> getline();
    last if (!defined($row_a));
        
    $csv_hoteldb -> write($row_a);
  }

}

1;


