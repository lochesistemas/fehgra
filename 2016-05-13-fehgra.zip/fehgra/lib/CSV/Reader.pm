#!/usr/bin/perl -w
use strict;
use warnings;

package CSV::Reader;
use strict;
use warnings;
use Text::CSV_PP;


sub new {
  my $class = shift;
  my %args = @_;

  my $csv_file = $args{csv_file} || die "csv_file not defined!!!";

  my $csv = Text::CSV_PP -> new ({binary => 1});
  open (my $cfh, "<:encoding(utf8)", "$csv_file") or die ("Error: Couln't open file $csv_file $!");

  my $heading_a = $csv -> getline($cfh);

  my $self = {
    csv_file => $csv_file,
    csv => $csv,
    cfh => $cfh,
    heading_a => $heading_a,
  };
  $self = bless $self, $class;

  return $self;
}

#-------------------------------------------------------------------------------
# Sub : getline
#-------------------------------------------------------------------------------
sub getline {
  my $self = shift;
  my $csv = $self -> {csv};
  my $cfh = $self -> {cfh};

  my $row_a = $csv -> getline($cfh);

  return $row_a;
}

#-------------------------------------------------------------------------------
# Sub : eof
#-------------------------------------------------------------------------------
sub eof {
  my $self = shift;
  my $csv = $self -> {csv};
  my $cfh = $self -> {cfh};

  return $csv -> eof($cfh);
}

1;




