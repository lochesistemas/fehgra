package Scrapy;
use strict;
use warnings;
use Scrapy::Despegar;
use Scrapy::Interpatagonia;
use Scrapy::Booking;
use DB::Web::Hotels;
use Data::Dump;
use Text::Utils;


sub new {
  my $class = shift;

  my %args = @_;

  my @valid = qw(userid password database table);

  foreach my $arg (@{valid}) {
    die "Argument $arg not defined!!" if (!defined($args{$arg}));
  }


  my $mech = WWW::Mechanize -> new(
    agent => 'Mozilla/5.0 (X11; Linux i686; rv:12.0) Gecko/20100101 Firefox/12.0',
  );

  my $userid = $args{userid};
  my $password = $args{password};
  my $database = $args{database};
  my $table= $args{table};
  my $city_id = $args{city_id};
  my $region_id = $args{region_id};
  my $domain = $args{domain};
  my $user_url = $args{user_url};
  my $query_id = $args{query_id};

  my $host_id_h = {};
  assign_host_ids ($host_id_h);

  my $host_links_h = CITY_LINKS;
  my $scrapy_a = [];
  if ($domain eq 'despegar.com.ar') {
    my $despegar = Scrapy::Despegar -> new(
      url => $user_url,
      hoteldb => DB::Web::Hotels -> new({
        userid => $userid,
        password => $password,
        database => $database,
        table => $table,
        host_id => $host_id_h -> {despegar},
        city_id => $city_id,
        region_id => $region_id,
        query_id => $query_id,
      }),
    );
    $scrapy_a = [$despegar];
  }
  elsif ($domain eq 'welcomeargentina.com') {
    my $interpatagonia = Scrapy::Interpatagonia -> new(
      url => $user_url,
      hoteldb => DB::Web::Hotels -> new({
        userid => $userid,
        password => $password,
        database => $database,
        table => $table,
        host_id => $host_id_h -> {interpatagonia},
        city_id => $city_id,
        region_id => $region_id,
        query_id => $query_id,
      }),
    );
    $scrapy_a = [$interpatagonia];
  }
  elsif ($domain eq 'booking.com') {print("$user_url\n");
    my $booking = Scrapy::Booking -> new(
      # url => $host_links_h -> {$city_id}{booking},
      url => $user_url,
      hoteldb => DB::Web::Hotels -> new({
        userid => $userid,
        password => $password,
        database => $database,
        table => $table,
        host_id => $host_id_h -> {booking},
        city_id => $city_id,
        region_id => $region_id,
        query_id => $query_id,
      }),
    );
    $scrapy_a = [$booking];
  }
  my $self = bless {
    mech => $mech,
    database => $database,
    table => $table,
    # scrapy_a => [$despegar, $interpatagonia, $booking],
    scrapy_a => $scrapy_a,
    host_id_h => $host_id_h,
  }, $class;
  return $self;

}

#-------------------------------------------------------------------------------
# Sub : assign_host_ids
#-------------------------------------------------------------------------------
sub assign_host_ids {
  my $host_id_h = shift;

  my $id = 1;

=comment
  $host_id_h -> {despegar} = $id++;
  $host_id_h -> {interpatagonia} = $id++;
  $host_id_h -> {booking} = $id++;
=cut

  $host_id_h -> {despegar} = 'despegar';
  $host_id_h -> {interpatagonia} = 'interpatagonia';
  $host_id_h -> {booking} = 'booking';
}

sub write_hotels {
  my $self = shift;
  my $mech = $self -> {mech};


  my $scrapy_a = $self -> {scrapy_a};

  foreach my $cscrapy (@{$scrapy_a}) {
    $cscrapy -> write_hotels;
  }

}


1;


