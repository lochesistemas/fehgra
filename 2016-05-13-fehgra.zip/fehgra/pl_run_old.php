<?php
include("include/connection.php");
$selectFiles=mysql_query("SELECT * FROM `userfiles` where state='0' LIMIT 0 , 10");
if(mysql_num_rows($selectFiles)>0) {
    # echo "Started running scrap_web_hotels.pl\n";
    while($resultFiles=mysql_fetch_array($selectFiles)) {
        $file_id = $resultFiles['id'];
        $query_id = $resultFiles['query_id'];
        $file_name = 'files/'.$resultFiles['file'];
        $user_id = $resultFiles['uid'];
        $domain = $resultFiles['domain'];
        $url = $resultFiles['url'];
        $city_id = '1';
        $region_id = '1';
        $select = mysql_query("SELECT id, name  from city");
        $cities = '';
        $cities_array = array();
        while($result=mysql_fetch_array($select)){
            $cities .= $result['name'].'|';
            $cities_array[$result['id']] = strtolower($result['name']);
        }
        $cities = rtrim($cities, '|');
        $select2 = mysql_query("SELECT c.id city_id,r.name region_name from region r JOIN `city` c ON r.id = c.rid GROUP BY r.id");
        $regions = '';
        $regions_array = array();
        while($result2=mysql_fetch_array($select2)){
            $regions .= strtolower($result2['region_name']).'|';
            $regions_array[$result2['city_id']] = strtolower($result2['region_name']);
        }
        $regions = rtrim($regions, '|');
        if($domain=='booking.com') {
            // http://www.booking.com/searchresults.es-ar.html?src=index&nflt=&error_url=http%3A%2F%2Fwww.booking.com%2Findex.es-ar.html%3Flabel%3Dgen173nr-1DCAEoggJCAlhYSDNiBW5vcmVmaAyIAQGYASy4AQzIAQzYAQPoAQGoAgM%3Bsid%3Ded6a7b4ba36594bcab664b7ea60b2d80%3Bdcid%3D1%3Bsb_price_type%3Dtotal%26%3B&dcid=1&label=gen173nr-1DCAEoggJCAlhYSDNiBW5vcmVmaAyIAQGYASy4AQzIAQzYAQPoAQGoAgM&lang=es-ar&sid=ed6a7b4ba36594bcab664b7ea60b2d80&si=ai%2Cco%2Cci%2Cre%2Cdi&ss=San+Carlos+de+Bariloche%2C+R%C3%ADo+Negro%2C+Argentina&room1=A%2CA&no_rooms=1&group_adults=2&group_children=0&ss_raw=san+carlos+de+bailoche&ac_position=0&ac_langcode=es&dest_id=-1012061&dest_type=city&ac_pageview_id=c6909a74a52300a3&ac_suggestion_list_length=8&ac_suggestion_theme_list_length=0&tfl_cwh=1
            if(preg_match('%&ss=(.+?)&%i', $url, $match)) {
                $city_phrase = preg_replace('%\s\s*%', ' ', str_replace(',', ' ', urldecode($match[1])));
                if(preg_match('%('.$cities.')%i', $city_phrase,$match2)) {
                    $city_id = array_search(strtolower($match2[1]),$cities_array);
                    if(false===$city_id) $city_id = '1';
                } elseif(preg_match('%('.$regions.')%i', $city_phrase,$match2)) {
                    $city_id = array_search(strtolower($match2[1]),$regions_array);
                    if(false===$city_id) $city_id = '1';
                }
            }
        } elseif($domain=='welcomeargentina.com') {
            //www.welcomeargentina.com/bariloche/alojamientos.html
            if(preg_match('%\.com/(.+?)/%i', $url, $match)) {
                $city_phrase = preg_replace('%\s\s*%', ' ', str_replace(',', ' ', urldecode($match[1])));
                if(preg_match('%('.$cities.')%i', $city_phrase,$match2)) {
                    $city_id = array_search(strtolower($match2[1]),$cities_array);
                    if(false===$city_id) $city_id = '1';
                } elseif(preg_match('%('.$regions.')%i', $city_phrase,$match2)) {
                    $city_id = array_search(strtolower($match2[1]),$regions_array);
                    if(false===$city_id) $city_id = '1';
                }
            }
        } elseif($domain=='despegar.com.ar') {
            //http://www.despegar.com.ar/hoteles/hl/901/i1/hoteles-en-san+carlos+de+bariloche?standard=false
            if(preg_match('%/hoteles\-en\-(.+?)\?%i', $url, $match) || preg_match('%/hoteles\-en\-(.+)%i', $url, $match)) {
                $city_phrase = preg_replace('%\s\s*%', ' ', str_replace(',', ' ', urldecode($match[1])));
                if(preg_match('%('.$cities.')%i', $city_phrase,$match2)) {
                    $city_id = array_search(strtolower($match2[1]),$cities_array);
                    if(false===$city_id) $city_id = '1';
                } elseif(preg_match('%('.$regions.')%i', $city_phrase,$match2)) {
                    $city_id = array_search(strtolower($match2[1]),$regions_array);
                    if(false===$city_id) $city_id = '1';
                }
            }
        }
        $selectCity = mysql_query("SELECT rid from city where id='$city_id'");
        $resultCity=mysql_fetch_array($selectCity);
        $region_id = $resultCity['rid'];
        mysql_query("UPDATE `userfiles` SET state='1' where id='$file_id';");
        $selectUsers = mysql_query("SELECT email from users where userid='$user_id';");
        $resultUsers=mysql_fetch_array($selectUsers);
        $email = $resultUsers['email'];
        exec('perl scrap_web_hotels.pl '.$city_id.' '.$region_id.' '.$domain.' '.urlencode($url)." '".$query_id."' ". "  2>&1", $output0, $e0);
        exec('perl parse_csv_hotels.pl '.$file_name." ".$user_id." '".$query_id."' ". "  2>&1", $output, $e);
        echo "<pre>";
        // print_r($output0);
        // print_r($output);
        
        $to = "$email";
        $subject = "FEHGRA - Su analisis fue completado!";
        $txt = "Estimado, usted ha solicitado un analisis de alojamientos informales. Puede encontrar el resultado en la seccion de Reportes. Muchas gracias!";
        $headers = "From: fehgra@hotelesdebariloche.com.ar";

        mail($to,$subject,$txt,$headers);
        sleep(10);
    }
}
echo "Completed running scrap_web_hotels.pl\n";

?>