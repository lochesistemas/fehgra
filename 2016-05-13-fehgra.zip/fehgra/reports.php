<?php include("include/connection.php");
?>
<!DOCTYPE html>
<html>
    <body class="skin-blue">
    <div class="wrapper">
		<?php include("include/header.php");?>
		<script type="text/javascript" language="javascript" src="js/jquery.js"></script>
		<script type="text/javascript" language="javascript" src="js/sidebar_js.js"></script>
		<script type="text/javascript" language="javascript" src="include/list_of_js/user.js"></script>
		<?php include("include/top_header.php");?>
      	<!-- Left side column. contains the logo and sidebar -->
      	<aside class="main-sidebar">
        <!-- sidebar: style can be found in sidebar.less -->
        <?php include("include/sidebar.php") ?>
        <!-- /.sidebar -->
      	</aside>
      	<!-- Content Wrapper. Contains page content -->
      	<div class="content-wrapper">
        <!-- Content Header (Page header) -->
        	<section class="content-header">
          		<h1>
            	Resultados
          		</h1>
          	<ol class="breadcrumb">
            	<li><a href="welcome.php"><i class="fa fa-dashboard"></i> Inicio</a></li>
            	<li><a href="reports.php">Resultados</a></li>
              <?php  if(isset($_GET['query_id'])): ?>
              <li><a href="reports.php?query_id=<?php echo $_GET['query_id']; ?>">Ver</a></li>
              <?php endif; ?>
          	</ol>
        	</section>
        <!-- Main content -->
		<div class="row">
        <?php 
        if(isset($_GET['query_id'])): 
            include("include/reports_view_tpl.php");
        else:
			     include("include/reports_tpl.php");
        endif; 
        ?>
		 </div><!-- /.content -->
      </div><!-- /.content-wrapper -->
      	<?php include("include/footer.php") ?>
    </div><!-- ./wrapper -->
	</body>
</html>