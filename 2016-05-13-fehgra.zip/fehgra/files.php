<?php include("include/connection.php");
if(isset($_GET['did'])){
	//$room_cat_name= $_GET['did'];
	mysql_query("delete FROM `userfiles` WHERE id=".$_GET['did']);
	header("location:files.php?msg=succ");
}
?>
<!DOCTYPE html>
<html>
    <body class="skin-blue">
    <div class="wrapper">
		<?php include("include/header.php");?>
		<script type="text/javascript" language="javascript" src="js/jquery.js"></script>
		<script type="text/javascript" language="javascript" src="js/sidebar_js.js"></script>
		<script type="text/javascript" language="javascript" src="include/list_of_js/user.js"></script>
		<?php include("include/top_header.php");?>
      	<!-- Left side column. contains the logo and sidebar -->
      	<aside class="main-sidebar">
        <!-- sidebar: style can be found in sidebar.less -->
        <?php include("include/sidebar.php") ?>
        <!-- /.sidebar -->
      	</aside>
      	<!-- Content Wrapper. Contains page content -->
      	<div class="content-wrapper">
        <!-- Content Header (Page header) -->
        	<section class="content-header">
          		<h1>
            	Archivos
          		</h1>
          	<ol class="breadcrumb">
            	<li><a href="admin_profile.php"><i class="fa fa-dashboard"></i> Inicio</a></li>
            	<li><a href="upload_file.php">Archivos</a></li>
          	</ol>
        	</section>
        <!-- Main content -->
		<div class="row">	 
			<?php include("include/files_tpl.php")?>
		 </div><!-- /.content -->
      </div><!-- /.content-wrapper -->
      	<?php include("include/footer.php") ?>
    </div><!-- ./wrapper -->
	</body>
</html>