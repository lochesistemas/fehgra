<?php
set_time_limit(0);
ini_set("log_errors", 1);
ini_set("error_log", __DIR__."/php_error.log");
error_reporting(E_ALL); ini_set('display_errors', 1);
include("include/connection.php");
include('include/simple_html_dom.php');
require('include/HotelScraper.php');
$lock = 'pl_run.lock';
$f = fopen($lock, 'w+');
if(flock($f,LOCK_EX|LOCK_NB)) {
    $selectFiles=mysql_query("SELECT * FROM `userfiles` where state='0' LIMIT 0 , 10");
    if(mysql_num_rows($selectFiles)>0) {
        # echo "Started running scrap_web_hotels.pl\n";
        while($resultFiles=mysql_fetch_array($selectFiles)) {
            if(file_exists(__DIR__.'/sql.txt')) unlink(__DIR__.'/sql.txt');
            $file_id = $resultFiles['id'];
            $query_id = $resultFiles['query_id'];
            $file_name = 'files/'.$resultFiles['file'];
            $user_id = $resultFiles['uid'];
            $domain = $resultFiles['domain'];
            $url = $resultFiles['url'];
            $city_id = '1';
            $city_name = '';
            $region_id = '1';
            $select = mysql_query("SELECT id, name  from city");
            $cities = '';
            $cities_array = array();
            while($result=mysql_fetch_array($select)){
                $cities .= $result['name'].'|';
                $cities_array[$result['id']] = strtolower($result['name']);
            }
            $cities .= 'buenos aires|';
            $cities = rtrim($cities, '|');
            if($domain=='booking.com') {
                // http://www.booking.com/searchresults.es-ar.html?src=index&nflt=&error_url=http%3A%2F%2Fwww.booking.com%2Findex.es-ar.html%3Flabel%3Dgen173nr-1DCAEoggJCAlhYSDNiBW5vcmVmaAyIAQGYASy4AQzIAQzYAQPoAQGoAgM%3Bsid%3Ded6a7b4ba36594bcab664b7ea60b2d80%3Bdcid%3D1%3Bsb_price_type%3Dtotal%26%3B&dcid=1&label=gen173nr-1DCAEoggJCAlhYSDNiBW5vcmVmaAyIAQGYASy4AQzIAQzYAQPoAQGoAgM&lang=es-ar&sid=ed6a7b4ba36594bcab664b7ea60b2d80&si=ai%2Cco%2Cci%2Cre%2Cdi&ss=San+Carlos+de+Bariloche%2C+R%C3%ADo+Negro%2C+Argentina&room1=A%2CA&no_rooms=1&group_adults=2&group_children=0&ss_raw=san+carlos+de+bailoche&ac_position=0&ac_langcode=es&dest_id=-1012061&dest_type=city&ac_pageview_id=c6909a74a52300a3&ac_suggestion_list_length=8&ac_suggestion_theme_list_length=0&tfl_cwh=1
                if(preg_match('%&ss=(.+?)&%i', $url, $match)) {
                    $city_phrase = preg_replace('%\s\s*%', ' ', str_replace(',', ' ', urldecode($match[1])));
                    if(preg_match('%('.$cities.')%i', $city_phrase,$match2)) {
                        if(strtolower($match2[1])=='buenos aires') {
                            $city_id = '7';
                            $city_name = 'capital federal';
                        } else {
                            $city_id = array_search(strtolower($match2[1]),$cities_array);
                            $city_name = $cities_array[$city_id];
                            if(false===$city_id) $city_id = '1';
                        }
                    }
                }
            } elseif($domain=='welcomeargentina.com') {
                //www.welcomeargentina.com/bariloche/alojamientos.html
                if(preg_match('%\.com/(.+?)/%i', $url, $match)) {
                    $city_phrase = preg_replace('%\s\s*%', ' ', str_replace(',', ' ', urldecode($match[1])));
                    if(preg_match('%('.$cities.')%i', $city_phrase,$match2)) {
                        if(strtolower($match2[1])=='buenos aires') {
                            $city_id = '7';
                            $city_name = 'capital federal';
                        } else {
                            $city_id = array_search(strtolower($match2[1]),$cities_array);
                            $city_name = $cities_array[$city_id];
                            if(false===$city_id) $city_id = '1';
                        }
                    }
                }
            } elseif($domain=='despegar.com.ar') {
                //http://www.despegar.com.ar/hoteles/hl/901/i1/hoteles-en-san+carlos+de+bariloche?standard=false
                if(preg_match('%/hoteles\-en\-(.+?)\?%i', $url, $match) || preg_match('%/hoteles\-en\-(.+)%i', $url, $match)) {
                    $city_phrase = preg_replace('%\s\s*%', ' ', str_replace(',', ' ', urldecode($match[1])));
                    if(preg_match('%('.$cities.')%i', $city_phrase,$match2)) {
                        if(strtolower($match2[1])=='buenos aires') {
                            $city_id = '7';
                            $city_name = 'capital federal';
                        } else {
                            $city_id = array_search(strtolower($match2[1]),$cities_array);
                            $city_name = $cities_array[$city_id];
                            if(false===$city_id) $city_id = '1';
                        }
                    }
                }
            }
            $selectCity = mysql_query("SELECT rid from city where id='$city_id'");
            $resultCity=mysql_fetch_array($selectCity);
            $region_id = $resultCity['rid'];
            $selectUsers = mysql_query("SELECT email from users where userid='$user_id';");
            $resultUsers=mysql_fetch_array($selectUsers);
            $email = $resultUsers['email'];
            $scraper = new HotelScraper();
            $success = $scraper->executeQuery("INSERT INTO `csv_addresses_tb` (address, lat, lng) values ('AV. ROQUE SÁENZ PEÑA 725 capital federal','-34.6060216','-58.3768474');");
            $csv = $scraper->parseCsv($file_name, $city_name);
            $host_id = str_replace(array('.com.ar','.com'), '', $domain);
            $hotels = array();
            if($domain=='welcomeargentina.com') {
                $hotels = $scraper->scrapeWelcomeArgentina($url);
            } elseif($domain=='despegar.com.ar') {
                $hotels = $scraper->scrapeDespegar($url);
            } elseif($domain=='booking.com') {
                $hotels = $scraper->scrapeBooking($url);
            }
            // file_put_contents(__DIR__.'/sql.txt', "start\n\r");
            $legal = 0;
            foreach ($hotels as $key => $row) {
                $hotels[$key]['legal'] = '0';
                foreach ($csv as $row_csv) {
                    if($row['lat'] && $row['lng'] && $row_csv['lat'] && $row_csv['lng'] && $scraper->compare_distance((float)$row['lat'], (float)$row['lng'], (float)$row_csv['lat'], (float)$row_csv['lng'], 20)) {
                        $hotels[$key]['legal'] = '1';$legal++;
                        break;
                    } elseif(preg_match('%'.preg_quote($row_csv['sort_hotel']).'%', $row['sort_hotel'])) {
                        $hotels[$key]['legal'] = '1';$legal++;
                        break;
                    }
                }
                // unset($hotels[$key]['lng']);
                // unset($hotels[$key]['lat']);
            }
            echo "scraped $url<br>";
            echo "Legal hotels: ".$legal.'<br>';
            echo "Illegal hotels: ".(count($hotels)-$legal).'<br>';
            // file_put_contents(__DIR__.'/sql.txt', "scraped $url\n\rLegal hotels: ".$legal."Illegal hotels: ".(count($hotels)-$legal)."\n\r");
            // echo "<pre>";print_r($hotels);
            $sql = '';
            if(!empty($hotels)) {
                $sql .= "INSERT INTO web_hotels_tb (host_id, query_id, region_id, city_id, url, hotel_name, website, __hotel__, __no_space_hotel__, __sort_hotel__, legal) values ";

                // $valuesArr = array();
                foreach($hotels as $row) {
                    $hotel = mysql_real_escape_string($row['hotel']);
                    $sort_hotel = mysql_real_escape_string($row['sort_hotel']);
                    $url = mysql_real_escape_string( $row['url'] );
                    $name = mysql_real_escape_string($row['name']);
                    $sql .= "('$host_id', '$query_id', '$region_id', '$city_id','".$url."', '".$name."', NULL, '".$hotel."', '".str_replace(' ', '', $hotel)."', '".$sort_hotel."', '".$row['legal']."'),";
                }
                $sql = rtrim($sql, ',');
                $sql .= ';';
                // $sql .= implode(',', $valuesArr).';';
            }
            $sql .= "INSERT INTO summary_hotel_results_tb (user_id, query_id, no_illegal_hotels, no_legal_hotels) values ('$user_id', '$query_id', '".(count($hotels)-$legal)."', '".$legal."');";
            $sql .= "UPDATE `userfiles` SET state='1' where id='$file_id';";
            // file_put_contents(__DIR__.'/sql.txt', $sql);
            $success = $scraper->executeQuery($sql);
            if(!$success) {
                file_put_contents(__DIR__.'/sql.txt', $sql);
                echo "<br>Failed MySql Query<br>";
            } else echo "<br>Success insert<br>";
            
            $to = "$email";
            $subject = "FEHGRA - Su analisis fue completado!";
            $txt = "Estimado, usted ha solicitado un analisis de alojamientos informales. Puede encontrar el resultado en la seccion de Reportes. Muchas gracias!";
            $headers = "From: fehgra@hotelesdebariloche.com.ar";

            mail($to,$subject,$txt,$headers);
            // sleep(10);
        }
    }
    echo "Completed running scrap_web_hotels.pl\n";
    flock($f,LOCK_UN);
} else {
    echo "Error locking file!";
}
fclose($f);
?>