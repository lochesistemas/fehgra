<?php include("include/connection.php")?>
<?php
	if(isset($_GET['action']) && $_GET['action']=="logout") {
		session_start();
		session_unset($_SESSION['id']);
		session_destroy();
	}
?>
<?php
	if(isset($_POST['submit'])) {
		$username=$_POST['username'];
		$password=$_POST['password'];
		$check_user = mysql_query("select * from users where name='".$username."' and password='".$password."' ");
		$check_user_array = mysql_fetch_array($check_user);
		if(empty($check_user_array)) {
			$msg_admin = "Please Enter Valid Details";
		} else {
			session_start();
			$_SESSION['id'] = $check_user_array['userid'];
			$_SESSION['username'] = $check_user_array['name'];
			$_SESSION['type'] = $check_user_array['typeid'];
                        $_SESSION['email'] = $check_user_array['email'];
			header("location:welcome.php");
		}
	}
?>
<!DOCTYPE html>
<html>
<head>
	<link href="plugins/iCheck/square/blue.css" rel="stylesheet" type="text/css" />
	<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<script src="plugins/jQuery/jQuery-2.1.3.min.js"></script>
    <!-- Bootstrap 3.3.2 JS -->
    <script src="bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
    <!-- iCheck -->
    <script src="plugins/iCheck/icheck.min.js" type="text/javascript"></script>
    <script>
      $(function () {
        $('input').iCheck({
          checkboxClass: 'icheckbox_square-blue',
          radioClass: 'iradio_square-blue',
          increaseArea: '20%' // optional
        });
      });
    </script>
</head>
    <body class="skin-blue">
    <div class="wrapper">
	<?php include("include/header.php") ?>
	<script type="text/javascript" language="javascript" src="js/jquery.js"></script>
	<script type="text/javascript" language="javascript" src="js/sidebar_js.js"></script>
	<script type="text/javascript" language="javascript" src="include/list_of_js/login.js"></script>
   
       <!-- Left side column. contains the logo and sidebar -->
      <aside class="main-sidebar">
        <!-- sidebar: style can be found in sidebar.less -->
        <!-- /.sidebar -->
      </aside>
      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
           <img src="logo.png">
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Inicio</a></li>
            <li><a href="#">Ingreso</a></li>
          </ol>
        </section>
        <!-- Main content -->
		<div class="row">
		<?php include("include/admin_login_form.php") ?> 
		</div><!-- /.content -->
      </div><!-- /.content-wrapper -->
      <?php include("include/footer.php") ?>
    </div><!-- ./wrapper -->

      </body>
</html>