#!/usr/bin/perl
use cPanelUserConfig;

use strict;
use warnings;

use Getopt::Std;
use CGI;
use Data::Dump;
use POSIX qw(strftime);


use lib 'lib';
use CSV2DB;
use DB::Analyse::Hotels;

#-------------------------------------------------------------------------------
# get_opts :
# Description : Get the command line options provided by the user
#-------------------------------------------------------------------------------
sub get_opts {
  my $opt = {};
  getopts('h', $opt);

  #-------------------------------------------------------------------------------
  #print help if -h given
  if (exists($opt -> {"h"})) {
    print_help();
    exit;
  }
  #-------------------------------------------------------------------------------

  return $opt;
}

#-------------------------------------------------------------------------------
# get_args :
# Description : Get the command line arguments provided by the user
#-------------------------------------------------------------------------------
sub get_args {
  my $query = CGI -> new();
  my $args = $query -> Vars;
  
  $args = {};
  $args -> {csv_file} = $ARGV[0] || die "csv_file arg not provided!!!";
  $args -> {user_id} = $ARGV[1] || die "user_id arg not provided!!!";
  $args -> {query_id} = $ARGV[2] || die "query_id arg not provided!!!";

  # Debug use
  $args -> {drop_table} = 0;

  return $args;

  #-------------------------------------------------------------------------------
  # Check for invalid argument and show warnings if found
  my @validArgs = ("user_id");
  my @allArgs = $query -> param();
  my @invalidArgs;
  foreach my $curArg (@allArgs) {
    push (@invalidArgs, $curArg) if ((grep ($curArg eq $_, @validArgs)) == 0);
  }

  warn ("Warning: Unknown argument '$_'") for (@invalidArgs);

  foreach my $curArg (@{validArgs}) {
    if (!defined($args -> {$curArg})) {
      die "$curArg argument not provided!!!";
    }
  }
  #-------------------------------------------------------------------------------

  return $args;
}

#-------------------------------------------------------------------------------
# print_help :
# Print help and exit
#-------------------------------------------------------------------------------
sub print_help {
my $helpTxt = <<EOF;

    +---------------------------------------------------------------------------------------------+
    |                     Help on $0
    +---------------------------------------------------------------------------------------------+
    | This script is used to scrape airbnb.com website
    |
    | Usages:
    |   perl <Path>/$0 <options> <arguments>
    |
    |   Note: Options must be provided before arguments.
    |
    | Options:
    |   -h : Print Help
    |
    | Arguments:
    |   user_id    : user_id of the user
    |   query_id   : query_id of the user
    |
    |   e.g. 1
    |   perl $0 -h
    |
    |   e.g. 2
    |   perl $0 user_id=42 query_id=1234
    |
    +---------------------------------------------------------------------------------------------+

EOF

  print ("$helpTxt\n");
  exit;
}

# Get the command line options and arguments and validate
my $in_opt = get_opts();
my $in_arg = get_args();

my $datestring = strftime "%Y-%m-%d %H:%M:%S", localtime;

#-------------------------------------------------------------------------------
# Create valid hotels database from input csv - START
#-------------------------------------------------------------------------------
my $csv2db = CSV2DB -> new(
  userid => 'hoteles_w3',
  password => 'w3@123',
  database => 'hoteles_w3',
  table => 'csv_hotels_tb',
  csv_file => $in_arg -> {csv_file},
  user_id => $in_arg -> {user_id},
  query_id => $in_arg -> {query_id},

  drop_table => $in_arg -> {drop_table},
);

$csv2db -> convert();
#-------------------------------------------------------------------------------
#  Create valid hotels database from input csv - START
#-------------------------------------------------------------------------------

#-------------------------------------------------------------------------------
# Analyse for illegal hotels - START
#-------------------------------------------------------------------------------
my $m_illegal = DB::Analyse::Hotels -> new(
  userid => 'hoteles_w3',
  password => 'w3@123',
  web_db_h => {
    database => 'hoteles_w3',
    table => 'web_hotels_tb',
  },
  csv_db_h => {
    database => 'hoteles_w3',
    table => 'csv_hotels_tb',
    user_id => $in_arg -> {user_id},
    query_id => $in_arg -> {query_id},
  },
  result_db_h => {
    database => 'hoteles_w3',
    l_table => 'valid_hotel_results_tb',
    i_table => 'illegal_hotel_results_tb',
    s_table => 'summary_hotel_results_tb',
    drop_table => $in_arg -> {drop_table},
  },
);

$m_illegal -> analyse_all();
#-------------------------------------------------------------------------------
# Analyse for illegal hotels - START
#-------------------------------------------------------------------------------





