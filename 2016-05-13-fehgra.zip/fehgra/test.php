<table border="2">
  <caption>Illegal Hotels</caption>
  <thead>
    <tr>
      <th>Sr. No</th>
      <th>Name</th>
      <th>Website</th>
      <th>Found On</th>
    </tr>
  </thead>
  <tbody>
<?php
  $db = new PDO('mysql:host=localhost;dbname=hoteles_w3;charset=utf8', 'hoteles_w3', 'w3@123');

  $query = '
   SELECT web_t.* FROM
      web_hotels_tb as web_t WHERE
      web_t.id NOT IN (SELECT result_t.web_hotel_id from valid_hotel_results_tb result_t)   
  ';

  $stmt = $db->query($query);

  $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
  
  if (count ($results) == 0) {
    echo '<tr><td colspan="4">No Rows Returned</td></tr>';
  }
  else {
    $sr_no = 1;
    foreach ($results as $result) {
      echo "<tr><td>{$sr_no}</td><td><a href={$result['url']}>{$result['hotel_name']}</a></td><td>{$result['website']}</td><td>{$result['host_id']}</td></tr>\n";
      $sr_no ++;
    }
  }

?>
  </tbody>
</table>
