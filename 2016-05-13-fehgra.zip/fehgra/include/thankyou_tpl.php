<?php include("include/list_of_js/admin_js1.js")?>
<?php
ini_set("display_errors",E_DEPRECATED);
?>
<div class="col-md-12">
		<div class="box box-primary">
                <div class="box-header">
                  <h3 class="box-title"></h3>
                </div><!-- /.box-header -->
                <!-- form start -->
				<p id="head"></p>
                <form role="form" method="post" name="form" action="">
                  <div class="box-body">
				  	<center><h1>MUCHAS GRACIAS!</h1></center></br>
				  	<p>El sistema se encargar&aacute; de procesar su pedido y se reflejar&aacuten en el menu de Reultados</p>


                  </div><!-- /.box-body -->

                  
                
     </div>
</div>