<?php
$show_data = "no";
$hotelsarr = array();
$query_id = date("Y-m-d H:i:s", strtotime('+4 hour'));

function getHostFromUrl($url)
{
    $host = @parse_url($url, PHP_URL_HOST);
    if (!$host) return false;
    if (substr($host, 0, 4) == "www.")
        $host = substr($host, 4);
    if (strlen($host) > 50)
        $host = substr($host, 0, 47) . '...';
    return $host;
}
function get_separator( $csvstring, $fallback = ';') {
    $seps = array(';',',','|',"\t");
    $max = 0;
    $separator = false;
    foreach($seps as $sep){
        $count = substr_count($csvstring, $sep);
        if($count > $max){
            $separator = $sep;
            $max = $count;
        }
    }

    if($separator) return $separator;
    return $fallback;
}
if(isset($_POST['submit']))
{
        $error = false;
        $fileext = end(explode(".",$_FILES['uploadex']['name']));

        $filename = rand(0,99999)."_".rand(0,99999).".".$fileext;
        if(!empty($_POST['hotels'])) {
            $hotelsarr = $_POST['hotels'];
            $hotels = "('".implode("','",$_POST['hotels'])."')";
        }
        $url = $_POST['url'];
        if(!preg_match('(http://|https://)', $url)) $url = 'http://'.$url;
        if($domain=getHostFromUrl($url)) {
            if($domain!='booking.com' && $domain!='welcomeargentina.com' && $domain!='despegar.com.ar') {
                $error = 'Wrong Domain Name!!';
            }
        } else {
            $error = 'Wrong URL!!';
        }
        $city_id = false;
        $region_id = false;
        $select = mysql_query("SELECT id, name from city");
        $cities = '';
        $cities_array = array();
        while($result=mysql_fetch_array($select)){
            $cities .= strtolower($result['name']).'|';
            $cities_array[$result['id']] = strtolower($result['name']);
        }
        $cities .= 'buenos aires|';
        $cities = rtrim($cities, '|');
        if($domain=='booking.com') {
            // http://www.booking.com/searchresults.es-ar.html?src=index&nflt=&error_url=http%3A%2F%2Fwww.booking.com%2Findex.es-ar.html%3Flabel%3Dgen173nr-1DCAEoggJCAlhYSDNiBW5vcmVmaAyIAQGYASy4AQzIAQzYAQPoAQGoAgM%3Bsid%3Ded6a7b4ba36594bcab664b7ea60b2d80%3Bdcid%3D1%3Bsb_price_type%3Dtotal%26%3B&dcid=1&label=gen173nr-1DCAEoggJCAlhYSDNiBW5vcmVmaAyIAQGYASy4AQzIAQzYAQPoAQGoAgM&lang=es-ar&sid=ed6a7b4ba36594bcab664b7ea60b2d80&si=ai%2Cco%2Cci%2Cre%2Cdi&ss=San+Carlos+de+Bariloche%2C+R%C3%ADo+Negro%2C+Argentina&room1=A%2CA&no_rooms=1&group_adults=2&group_children=0&ss_raw=san+carlos+de+bailoche&ac_position=0&ac_langcode=es&dest_id=-1012061&dest_type=city&ac_pageview_id=c6909a74a52300a3&ac_suggestion_list_length=8&ac_suggestion_theme_list_length=0&tfl_cwh=1
            if(preg_match('%&ss=(.+?)&%i', $url, $match)) {
                $city_phrase = preg_replace('%\s\s*%', ' ', str_replace(',', ' ', urldecode($match[1])));
                if(preg_match('%('.$cities.')%i', $city_phrase,$match2)) {
                    if(strtolower($match2[1])=='buenos aires') {
                        $city_id = '7';
                    } else {
                        $city_id = array_search(strtolower($match2[1]),$cities_array);
                        if(false===$city_id) $city_id = '1';
                    }
                }
            } else {
                $error = 'Wrong URL Format!!';
            }
        } elseif($domain=='welcomeargentina.com') {
            //www.welcomeargentina.com/bariloche/alojamientos.html
            if(preg_match('%welcomeargentina\.com/(.+?)/%i', $url, $match)) {
                $city_phrase = preg_replace('%\s\s*%', ' ', str_replace(',', ' ', urldecode($match[1])));
                if(preg_match('%('.$cities.')%i', $city_phrase,$match2)) {
                    if(strtolower($match2[1])=='buenos aires') {
                        $city_id = '7';
                    } else {
                        $city_id = array_search(strtolower($match2[1]),$cities_array);
                        if(false===$city_id) $city_id = '1';
                    }
                }
            } else {
                $error = 'Wrong URL Format!!';
            }
        } elseif($domain=='despegar.com.ar') {
            //http://www.despegar.com.ar/hoteles/hl/901/i1/hoteles-en-san+carlos+de+bariloche?standard=false
            if(preg_match('%/hoteles\-en\-(.+?)\?%i', $url, $match) || preg_match('%/hoteles\-en\-(.+)%i', $url, $match)) {
                $city_phrase = preg_replace('%\s\s*%', ' ', str_replace(',', ' ', urldecode($match[1])));
                if(preg_match('%('.$cities.')%i', $city_phrase,$match2)) {
                    if(strtolower($match2[1])=='buenos aires') {
                        $city_id = '7';
                    } else {
                        $city_id = array_search(strtolower($match2[1]),$cities_array);
                        if(false===$city_id) $city_id = '1';
                    }
                }
            } else {
                $error = 'Wrong URL Format!!';
            }
        }
        $selectCity = mysql_query("SELECT rid from city where id='$city_id'");
        $resultCity=mysql_fetch_array($selectCity);
        $region_id = $resultCity['rid'];
        if(!$error) {
            $itag = $_POST['itag'];
            $path = "files/";
            $file = fopen($_FILES['uploadex']['tmp_name'],"r");
            $file2 = fopen($path.$filename,"w");
            $seperator = get_separator(fread($file, filesize($_FILES['uploadex']['tmp_name'])));
            rewind($file);
            while(($line=fgetcsv($file, 0, $seperator))!==false) {
                fputcsv($file2,$line, ',');
            }
            fclose($file);
            fclose($file2);
            mysql_query("INSERT INTO `userfiles` (`uid`,`query_id`,`file`,`domain`,`url`,`source`,`city_id`,`region_id`) VALUES ('".$_SESSION['id']."','".$query_id."','".$filename."','".$domain."','".$url."','".$itag."','".$city_id."','".$region_id."');");
            if ($_FILES['uploadex']['name'] != "" /*&& !empty($hotels)*/) {
                $perl_cmd = "perl parse_csv_hotels.pl ".$path.$filename . " " . $_SESSION['id'] . ' "' . $query_id . '"' . "  2>&1";
                // exec($perl_cmd, $output,$e);
            }        }
        $show_data = "yes";
        //header("location:files.php");
}
if(isset($_POST['update']))
{
        $fileext = end(explode(".",$_FILES['uploadex']['name']));

        $filename = rand(0,99999)."_".rand(0,99999).".".$fileext;
        $eid = $_GET['eid'];
        $path = "files/";
        move_uploaded_file($_FILES['uploadex']['tmp_name'],$path.$filename);
        mysql_query("update userfiles set `uid`='".$_SESSION['id']."',`file`='".$filename."' where id='".$eid."';");
        header("location:files.php");
}
if(isset($_GET['eid'])) {

        $select_sec=mysql_query("SELECT * FROM `userfiles` where id=".$_GET['eid']);
        $sec_detail_edit = mysql_fetch_array($select_sec);
        $file = $sec_detail_edit['file'];
}
?>

<div class="col-md-12">
        <div class="box box-primary">
        <div class="box-header">
            <?php if(isset($error) && $error) : ?>
                <p class="text-red" style="font-size:18px; font-family:Verdana, Arial, Helvetica, sans-serif;"><?php echo $error;?></p>
            <?php endif; ?>
        </div><!-- /.box-header -->
        <!-- form start -->
                <form role="form" enctype="multipart/form-data" method="post" name="form" action="">
                                <div class="box-body">
                                        
                                        <div class="form-group">
                      <label for="categoryName">Direccion Web (C&oacute;mo obtengo la <a href="ayuda.pdf" target="_blank"">direcci&oacute;n</a>?)</label><br />
                                <input type="text" name="url" />
                                                <p id="typeerr" class="text-red"></p>
                                                </div>        
                                                
                                        <div class="form-group">
                      <label for="categoryName">Listado Oficial (formato CSV) - <a href="modelo.csv">Descargar modelo</a></label>
                                <input type="file" name="uploadex" />
                                                <p id="typeerr" class="text-red"></p>
                                        </div>
                                 
                                            
                                                <div class="form-group">
                      <label for="categoryName">Origen del listado oficial</label><br />
                                <input type="text" name="itag" placeholder="Ej: Municipalidad" />
                                                <p id="typeerr" class="text-red"></p>
                                                </div>   
                                        <p><strong>Tenga en cuenta que el an&aacute;lisis no se efectuar&aacute; en el momento y que puede demorar varias horas.<br> Recibir&aacute; un correo electr&oacute;nico una vez finalizado el mismo. Revise que su direcci&oacute;n de correo sea la correcta en el menu <a href="admin_profile.php">Perfil</a></strong></p>
                                        </div>

                                        


                                  <div class="box-footer">
                                        <?php if(isset($_GET['eid'])) { ?>
                    <button id="update" name="update" type="submit" class="submitchk btn btn-primary">Actualizar</button>
                                        <?php } else { ?>
                                        <button id="submit" name="submit" type="submit" class="submitchk btn btn-primary">Comenzar el analisis</button>
                                        <?php }?>
                  </div>
                  </div>
                </form>
        </div><!-- box-primary-->
</div>
<?php
if($show_data=="yes") {
    if(!isset($error) || !$error) :?>
    <script type="text/javascript">
        window.location.href = 'http://hotelesdebariloche.com.ar/fehgra/thankyou.php';
    </script>
    <?php endif;
//$email = $_SESSION['email'];
//$email = 'haffoudhimedtaieb@gmail.com';
//$to = "$email";
//$subject = "FEHGRA - Su analisis fue completado!";
//$txt = "Estimado, usted ha solicitado un analisis de alojamientos informales. Puede encontrar el resultado en la seccion de Reportes. Muchas gracias!";
//$headers = "From: fehgra@hotelesdebariloche.com.ar";

//mail($to,$subject,$txt,$headers);
// ?>


        </div>
        </div><!-- box-primary-->
</div>

<?php } ?>