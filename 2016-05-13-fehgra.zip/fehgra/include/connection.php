<?php
//echo basename($_SERVER['PHP_SELF']);exit;
if(basename($_SERVER['PHP_SELF'])!="index.php") {
session_start();
if(!isset($_SESSION['id'])){
	header("location:index.php");
}
}
//if(session_status()!=PHP_SESSION_ACTIVE) session_start();
mysql_connect("localhost","hoteles_w3","w3@123");		
mysql_select_db("hoteles_w3");
?>