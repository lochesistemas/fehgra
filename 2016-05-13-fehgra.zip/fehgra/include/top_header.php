<header class="main-header">
<!-- Logo -->
<a href="welcome.php" class="logo"><b>FEHGRA</b></a>
<!-- Header Navbar: style can be found in header.less -->
<nav class="navbar navbar-static-top" role="navigation">
<!-- Sidebar toggle button-->
<!-- Navbar Right Menu -->
</nav>
</header>