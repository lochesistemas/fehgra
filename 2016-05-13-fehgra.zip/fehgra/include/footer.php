<footer class="main-footer">
        <div class="pull-right hidden-xs">
          <b>Version</b> 1.0
        </div>
        <strong>Plataforma de Identificación de Oferta Informal del Departamento de Actividades Informales de la FEHGRA. Desarrollado por Loche Sistemas.</strong>
</footer>
<script src="plugins/jQuery/jQuery-2.1.3.min.js"></script>
    <!-- Bootstrap 3.3.2 JS -->
    <script src="bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
    <!-- DATA TABES SCRIPT -->
    <!--<script src="plugins/datatables/jquery.dataTables.js" type="text/javascript"></script>
    <script src="plugins/datatables/dataTables.bootstrap.js" type="text/javascript"></script>-->
    <script type="text/javascript" src="https://cdn.datatables.net/t/bs/dt-1.10.11/datatables.min.js"></script>
    <script src="plugins/TableTools/js/dataTables.tableTools.min.js" type="text/javascript"></script>
    <!-- SlimScroll -->
    <script src="plugins/slimScroll/jquery.slimscroll.min.js" type="text/javascript"></script>
    <!-- FastClick -->
    <script src='plugins/fastclick/fastclick.min.js'></script>
    <!-- AdminLTE App -->
    <script src="dist/js/app.min.js" type="text/javascript"></script>
    <!-- page script -->
    <script type="text/javascript">
      $(function () {
    //alert("in");
        $("#example1").dataTable({"sPaginationType": "full_numbers",});
        $("#example2").dataTable({"sPaginationType": "full_numbers",});
        $("#example3").dataTable({  
          "language": {
          "sProcessing":     "Procesando...",
          "sLengthMenu":     "Mostrar _MENU_ registros",
          "sZeroRecords":    "No se encontraron resultados",
          "sEmptyTable":     "Ningún dato disponible en esta tabla",
          "sInfo":           "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
          "sInfoEmpty":      "Mostrando registros del 0 al 0 de un total de 0 registros",
          "sInfoFiltered":   "(filtrado de un total de _MAX_ registros)",
          "sInfoPostFix":    "",
          "sSearch":         "Buscar:",
          "sUrl":            "",
          "sInfoThousands":  ",",
          "sLoadingRecords": "Cargando...",
          "oPaginate": {
              "sFirst":    "Primero",
              "sLast":     "Último",
              "sNext":     "Siguiente",
              "sPrevious": "Anterior"
              },
          "oAria": {
              "sSortAscending":  ": Activar para ordenar la columna de manera ascendente",
              "sSortDescending": ": Activar para ordenar la columna de manera descendente"
              }
               } , 
           "sPaginationType": "full_numbers",
            "order": [[ 0, "desc" ]]
          });
          var table = $("#example4").dataTable({  
            "language": {
            "sProcessing":     "Procesando...",
            "sLengthMenu":     "Mostrar _MENU_ registros",
            "sZeroRecords":    "No se encontraron resultados",
            "sEmptyTable":     "Ningún dato disponible en esta tabla",
            "sInfo":           "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
            "sInfoEmpty":      "Mostrando registros del 0 al 0 de un total de 0 registros",
            "sInfoFiltered":   "(filtrado de un total de _MAX_ registros)",
            "sInfoPostFix":    "",
            "sSearch":         "Buscar:",
            "sUrl":            "",
            "sInfoThousands":  ",",
            "sLoadingRecords": "Cargando...",
            "oPaginate": {
                "sFirst":    "Primero",
                "sLast":     "Último",
                "sNext":     "Siguiente",
                "sPrevious": "Anterior"
                },
            "oAria": {
                "sSortAscending":  ": Activar para ordenar la columna de manera ascendente",
                "sSortDescending": ": Activar para ordenar la columna de manera descendente"
                }
                 } , 
             "sPaginationType": "full_numbers", 
              "columnDefs": [{"targets": [ 3 ], "visible": false,"searchable": false }]
          });
       $.fn.dataTable.TableTools.defaults.sSwfPath = "plugins/TableTools/swf/copy_csv_xls_pdf.swf";          
        $.fn.dataTable.TableTools.defaults.aButtons = [
              {"sExtends": "copy", "mColumns": [0,1,2,3]},
              {"sExtends": "pdf", "mColumns": [0,1,2,3]},
              {"sExtends": "csv", "mColumns": [0,1,2,3]},
              {"sExtends": "xls", "sFileName": "*.xls", "mColumns": [0,1,2,3]}
          ];
        var tt = new $.fn.dataTable.TableTools( table );
        $( tt.fnContainer() ).insertBefore('div.dataTables_wrapper');
      });
    </script>