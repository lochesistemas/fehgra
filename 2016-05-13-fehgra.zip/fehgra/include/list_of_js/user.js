$(document).ready(function(){
						   
	$("#usertype").change(function(){
		var tid = $(this).val();
		$(".sidtype").hide();
		$("#sidtype_"+tid).show();
	})
	$("#usertype").trigger("change");
	$(".submitchk").click(function(){
	var sname=$("#username").val();
	var usertype=$("#usertype").val();
	var email=$("#email").val();
	var pass=$("#password").val();
	
	var name_regex = /^[a-z A-Z]+$/;
	var flag = true
	
	if(usertype==""){
		$('#typeerr').text("* Seleccione tipo de usuario"); 
		$("#usertype").focus();
		flag=false;
	}else {
		$('#typeerr').text("");
	}
	if(sname==""){
		$('#p1').text("* Ingrese nombre de usuario"); 
		$("#username").focus();
		flag=false;
	}else {
		$('#p1').text("");
	}
	
	if(email==""){
		$('#emailerr').text("* Ingrese el correo electronico"); 
		$("#email").focus();
		flag=false;
	}else {
		$('#emailerr').text("");
	}

	if(pass==""){
		$('#passerr').text("* Ingrese la clave"); 
		$("#password").focus();
		flag=false;
	}else {
		$('#passerr').text("");
	}

	if(flag) {
		return true;
	} else{
		return false;
	}	
 })

})
function delete_category()
	{
		var r = confirm("Esta seguro que quiere eliminar este usuario?");
		return r;
	}