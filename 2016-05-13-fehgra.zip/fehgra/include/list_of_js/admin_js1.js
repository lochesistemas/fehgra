<script src="js/jquery.js"  language="javascript" type="text/javascript" ></script>
<script type="text/javascript" language="javascript">
$(document).ready(function(){
	$("#submit").click(function(){	
	var username=$("#username").val();
	var password=$("#password").val();
	var cpassword=$("#cpassword").val();
	var email=$("#email").val();
	var name_regex = /^[a-z A-Z]+$/;
	var email_regex = /^[\w\-\.\+]+\@[a-zA-Z0-9\.\-]+\.[a-zA-z0-9]{2,4}$/;
	var flag = true
	if(!username.match(name_regex)|| username==""){
		$('#p1').text("*Please use only alphabatic word");
		$("#username").focus();
		flag=false;
	}else {
		$('#p1').text("");
	}
	if(password==""){
		$('#p2').text("*Please enter password");
		$("#password").focus();
		flag=false;
	}else {
		$('#p2').text("");
	}
	if(cpassword != password|| cpassword==""){
		$('#p3').text("*Please enter correct password....");
		$("#cpassword").focus();
		flag=false;
	}else {
		$('#p3').text("");
	}
	if(!email.match(email_regex)|| email==""){
	$("#p4").text("*Please enter valid Email id");
		$("#email").focus();
		flag=false;
	} else {
		$('#p4').text("");
	}
	if(flag) {
		return true;
	} else{
		return false;
	}
 })
})
</script>