$(document).ready(function(){
	$("#submit").click(function(){
	var rcname = $('#rcname').val();
	var rfname=$(".rfname").val();
	var rdescription=$("#rdescription").val();
	var rprice=$("#rprice").val();
	var file=$("#file").val();
	var name_regex = /^[a-z A-Z 0-9]+$/;
	var rprice_regex = /^[0-9]+$/;
	var flag = true
	
	if ($("#rcname").val()== "please" || $("#rcname").val()== null) {
		$('#p1').text("* Please choose any one category"); // This Segment Displays The Validation Rule For Selection
		$("#rcname").focus();
		flag=false;
	}else {
		$('#p1').text("");
	}
	if($(".rfname:checked").size()<1){
		$("#p2").text("Please select atleast one features");
		$(".rfname").focus();
		flag=false;
	}else{
		$('#p2').text("");
	}
	if(rdescription.length == 0){
		$('#p3').text("*Please enter valid description");
		$("#rdescription").focus();
		flag=false;
	} else {
		$('#p3').text("");
	}
	if(!(rprice.match(rprice_regex) && rprice.length==3) || rprice.length == 0){
		$('#p4').text("*Please enter valid price");
		$("#rprice").focus();
		flag=false;
	} else {
		$('#p4').text("");
	}
	if(file == 0){
		$('#p5').text("*Please enter valid description");
		$("#rdescription").focus();
		flag=false;
	} else {
		$('#p5').text("");
	}
	if(flag) {
		return true;
	} else{
		return false
	}
})
	
	$("#update").click(function(){
	var rcname = $('#rcname').val();
	var rfname=$(".rfname").val();
	var rdescription=$("#rdescription").val();
	var rprice=$("#rprice").val();
	var name_regex = /^[a-z A-Z 0-9]+$/;
	var rprice_regex = /^[0-9]+$/;
	var flag = true
	
	if ($("#rcname").val()== "please" || $("#rcname").val()== null) {
		$('#p1').text("* Please Choose any one category"); // This Segment Displays The Validation Rule For Selection
		$("#rcname").focus();
		flag=false;
	}else {
		$('#p1').text("");
	}
	if($(".rfname:checked").size()<1){
		$("#p2").text("Please select atleast one features");
		$(".rfname").focus();
		flag=false;
	}else{
		$('#p2').text("");
	}
	if(rdescription.length == 0){
		$('#p3').text("*Please enter valid description");
		$("#rdescription").focus();
		flag=false;
	} else {
		$('#p3').text("");
	}
	if(!(rprice.match(rprice_regex) && rprice.length==3) || rprice.length == 0){
		$('#p4').text("*Please enter valid price");
		$("#rprice").focus();
		flag=false;
	} else {
		$('#p4').text("");
	}
	if(flag) {
		return true;
	} else{
		return false
	}
	})
	
})
function delete_room(){
		var r=confirm("Are you sure to delete this??");
		return r;
	}