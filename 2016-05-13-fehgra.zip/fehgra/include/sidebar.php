<section class="sidebar">
<!-- Sidebar user panel -->
<div class="user-panel">
<div class="pull-left image">
<img src="dist/img/bittu.jpg" class="img-circle" alt="User Image" />
</div>
<div class="pull-left info">
<p><?php echo $_SESSION['username'];?></p>
<a href="index.php?action=logout"><i class="fa fa-circle text-success"></i> Cerrar Sesion</a>
</div>
</div>
<ul class="sidebar-menu">
<li>
<a class="myclass" href="admin_profile.php"><i class="fa fa-dashboard"></i>
<span>Perfil</span>
<i class="fa fa-angle-left pull-right"></i>
</a>
</li>
<li>
<a class="myclass" href="upload_file.php"><i class="fa fa-dashboard"></i>
<span>Realizar an&aacute;lisis</span>
<i class="fa fa-angle-left pull-right"></i>
</a>
</li>
<li>
<a class="myclass" href="reports.php"><i class="fa fa-dashboard"></i>
<span>Resultados</span>
<i class="fa fa-angle-left pull-right"></i>
</a>
</li>

<?php if($_SESSION['type']=='1') { ?>
<li>
<a class="myclass" href="user_master.php"><i class="fa fa-dashboard"></i>
<span>Gesti&oacute;n de Usuarios</span>
<i class="fa fa-angle-left pull-right"></i>
</a>
</li>
<?php } ?>
</ul>
</section>