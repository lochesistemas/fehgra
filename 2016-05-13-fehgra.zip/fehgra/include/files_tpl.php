<div class="col-md-12">
  	<div class="box">
         <div class="box-header">
		 	<?php if(isset($_GET['msg'])){
				$msg=$_GET['msg'];?>
				<p class="text-green" style="font-size:18px; font-family:Verdana, Arial, Helvetica, sans-serif;"><?php echo "Record Deleted SuccessFully";?></p>
		 	<?php }?>
              
         </div><!-- /.box-header -->
         <div class="box-body">
		 <?php 
				$select=mysql_query("SELECT * FROM `userfiles`");
					if(mysql_num_rows($select)>0){
		 ?>
        <table id="example1" class="table table-bordered table-striped">
              <thead>
			  <tr>
                   <th style="width: 10px">Id</th>
                   <th>File</th>
				  	<th style="width: 40px">Action</th>
              </tr>
			  </thead>
			  <tbody>
			<?php 
			$counter=1;
				while($result=mysql_fetch_array($select)){
			?>
              <tr>
                    <td><?php echo $counter;?></td>
                    <td><?php echo $result["file"];?></td>
					
					 <td>
					  <a class="btn btn-block btn-danger btn-xs" onclick="return delete_category();" href="upload_file.php?did=<?php echo $result["id"];?>">DELETE</a>
                     </td>
					 </tr>
					<?php $counter++;}?>
             </tbody>
	 	</table>
				  <?php }?>
      	</div><!-- /.box-body -->
            <!--<div class="box-footer clearfix">
                  <ul class="pagination pagination-sm no-margin pull-right">
                    <li><a href="#">�</a></li>
                    <li><a href="#">1</a></li>
                    <li><a href="#">2</a></li>
                    <li><a href="#">3</a></li>
                    <li><a href="#">�</a></li>
                  </ul>
             </div>-->
	</div>
</div>		  
		        
