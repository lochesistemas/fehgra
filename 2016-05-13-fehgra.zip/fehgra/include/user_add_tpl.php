<?php
if(isset($_POST['submit']))
{
	$username= $_POST['username'];
	$email= $_POST['email'];
	$password= $_POST['password'];
	$phone= $_POST['phone'];
	$type= $_POST['usertype'];
	if($type=="2") { 
		$sid= $_POST['rid'];
	} elseif($type=="3") {
		$sid= $_POST['sid'];
	} else {
		$sid = "";
	}
	$phone2= $_POST['phone2'];
	$add1= $_POST['add1'];
	$add2= $_POST['add2'];
	mysql_query("INSERT INTO `users` (`name`,`email`,`password`,`phone`,`typeid`,`sid`,`phone2`,`add1`,`add2`) VALUES ('".$username."','".$email."','".$password."','".$phone."','".$type."','".$sid."','".$phone2."','".$add1."','".$add2."');");
	?>
<script type="text/javascript">
window.location.href = 'user_master.php';
</script>
<?php
}
if(isset($_POST['update']))
{
	$username= $_POST['username'];
	$email= $_POST['email'];
	$password= $_POST['password'];
	$phone= $_POST['phone'];
	$type= $_POST['usertype'];
	if($type=="2") { 
		$sid= $_POST['rid'];
	} elseif($type=="3") {
		$sid= $_POST['sid'];
	} else {
		$sid = "";
	}
	$sid= $_POST['sid'];
	$phone2= $_POST['phone2'];
	$add1= $_POST['add1'];
	$add2= $_POST['add2'];
	mysql_query("update `users` set `name`='".$username."', `email`='".$email."',`password`='".$password."',`phone`='".$phone."',`typeid`='".$type."',`sid`='".$sid."',`phone2`='".$phone2."',`add1`='".$add1."',`add2`='".$add2."' where userid=".$_GET['eid']);
	?>
<script type="text/javascript">
window.location.href = 'user_master.php';
</script>
<?php
}
$typeid = '';
$rid = '';
$cid = '';
if(isset($_GET['eid'])) {
	
	$select_sec=mysql_query("SELECT * FROM `users` where userid=".$_GET['eid']);
	$sec_detail_edit = mysql_fetch_array($select_sec);
	$typeid = $sec_detail_edit['typeid'];
	$rid = $sec_detail_edit['sid'];
	$cid = $sec_detail_edit['sid'];
}
$select_sec_get=mysql_query("SELECT * FROM `usertype`");
$select_region_get=mysql_query("SELECT * FROM `region`");
$select_city_get=mysql_query("SELECT * FROM `city`");
?>

<div class="col-md-12">
	<div class="box box-primary">
    	<div class="box-header">
        	<h3 class="box-title"></h3>
        </div><!-- /.box-header -->
        <!-- form start -->
                <form role="form" method="post" name="form" action="">
				<div class="box-body">
				  	<div class="form-group">
                      <label for="categoryName">Tipo de Usuario</label>
                  		<select class="form-control" name="usertype" id="usertype">
						<!--<option value="0">Select</option>-->
						<?php
						while($sec_detail = mysql_fetch_array($select_sec_get)){?>
							<option <?php if($typeid == $sec_detail['typeid']) { ?> selected="selected" <?php } ?> value="<?php echo $sec_detail['typeid'];?>"><?php echo $sec_detail['type'];?></option>
						<?php } ?>
						</select>
						<p id="typeerr" class="text-red"></p>
						</div>
					</div>
					
					<div id="sidtype_2" class="sidtype box-body">
				  	<div class="form-group">
                      <label for="categoryName">Region</label>
                  		<select class="form-control" name="rid" id="rid">
						<!--<option value="0">Select</option>-->
						<?php
						while($region_detail = mysql_fetch_array($select_region_get)){?>
							<option <?php if($rid == $region_detail['id']) { ?> selected="selected" <?php } ?> value="<?php echo $region_detail['id'];?>"><?php echo $region_detail['name'];?></option>
						<?php } ?>
						</select>
						<p id="riderr" class="text-red"></p>
						</div>
					</div>
					<div id="sidtype_3" class="sidtype box-body">
				  	<div class="form-group">
                      <label for="categoryName">Ciudad</label>
                  		<select class="form-control" name="sid" id="sid">
						<!--<option value="0">Select</option>-->
						<?php
						while($city_detail = mysql_fetch_array($select_city_get)){?>
							<option <?php if($cid == $city_detail['id']) { ?> selected="selected" <?php } ?> value="<?php echo $city_detail['id'];?>"><?php echo $city_detail['name'];?></option>
						<?php } ?>
						</select>
						<p id="ciderr" class="text-red"></p>
						</div>
					</div>
                  <div class="box-body">
				  	<div class="form-group">
                      <label for="categoryName">Usuario</label>
                      <input type="text" class="form-control" id="username" name="username" value="<?php if(isset($sec_detail_edit['name'])) { echo $sec_detail_edit['name'];}?>" placeholder="Ingrese el nombre de usuario"><p id="p1" class="text-red"></p>
                    </div>
                  </div><!-- /.box-body -->
				  <div class="box-body">
				  	<div class="form-group">
                      <label for="categoryName">Contrase&ntilde;a</label>
                      <input type="text" class="form-control" id="password" name="password" value="<?php if(isset($sec_detail_edit['password'])) { echo $sec_detail_edit['password'];}?>" placeholder="Contrase&ntilde;a"><p id="passerr" class="text-red"></p>
                    </div>
                  </div><!-- /.box-body -->
				  
				  <div class="box-body">
				  	<div class="form-group">
                      <label for="categoryName">Email</label>
                      <input type="text" class="form-control" id="email" name="email" value="<?php if(isset($sec_detail_edit['email'])) { echo $sec_detail_edit['email'];}?>" placeholder="Email"><p id="emailerr" class="text-red"></p>
                    </div>
                  </div><!-- /.box-body -->
				  
				  <div class="box-body">
				  	<div class="form-group">
                      <label for="categoryName">Telefono Oficina</label>
                      <input type="text" class="form-control" id="phone" name="phone" value="<?php if(isset($sec_detail_edit['phone'])) { echo $sec_detail_edit['phone'];}?>" placeholder="ej: 011 4444-4444"><p id="phmerr" class="text-red"></p>
                    </div>
                  </div><!-- /.box-body -->
				  
				  <div class="box-body">
				  	<div class="form-group">
                      <label for="categoryName">Celular</label>
                      <input type="text" class="form-control" id="phone2" name="phone2" value="<?php if(isset($sec_detail_edit['phone2'])) { echo $sec_detail_edit['phone2'];}?>" placeholder="ej: 011 154444-4444"><p id="phmerr" class="text-red"></p>
                    </div>
                  </div><!-- /.box-body -->
				  
				  
				  <div class="box-body">
				  	<div class="form-group">
                      <label for="categoryName">Direccion 1</label>
                      <input type="text" class="form-control" id="add1" name="add1" value="<?php if(isset($sec_detail_edit['add1'])) { echo $sec_detail_edit['add1'];}?>" placeholder="ej: Larrea 1250"><p id="phmerr" class="text-red"></p>
                    </div>
                  </div><!-- /.box-body -->
				  
				  <div class="box-body">
				  	<div class="form-group">
                      <label for="categoryName">Direccion 2</label>
                      <input type="text" class="form-control" id="add2" name="add2" value="<?php if(isset($sec_detail_edit['add2'])) { echo $sec_detail_edit['add2'];}?>" placeholder="ej: 1A"><p id="phmerr" class="text-red"></p>
                    </div>
                  </div><!-- /.box-body -->
				  
				  
				  <div class="box-footer">
				  	<?php if(isset($_GET['eid'])) { ?>
                    <button id="update" name="update" type="submit" class="submitchk btn btn-primary">Actualizar</button>
					<?php } else { ?>
					<button id="submit" name="submit" type="submit" class="submitchk btn btn-primary">Guardar</button>
					<?php }?>
                  </div>
                </form>
	</div><!-- box-primary-->
</div>