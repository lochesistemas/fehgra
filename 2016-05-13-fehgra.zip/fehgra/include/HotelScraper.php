<?php
Class HotelScraper {
    public $pdo;
    protected $curl;
    protected $curl2;
    /*public $pdo;
    function __construct() {
        $this->pdo = new PDO("mysql:host=localhost;dbname=hoteles_w3", 'hoteles_w3', 'w3@123');
    }*/
    function executeQuery($sql, $select=false)
    {
        try {
            $this->runQuery($sql, $select);
        }
        catch (PDOException $e)
        {
            try {
                sleep(2);
                $this->runQuery($sql, $select);
            }
            catch (PDOException $e2)
            {
                echo $e2->getMessage()."<br>";
            }
        }
    }
    function runQuery($sql, $select=false)
    {
        if(!$this->pdo) {
            $this->pdo = new PDO("mysql:host=localhost;dbname=hoteles_w3;charset=utf8;", 'hoteles_w3', 'w3@123', array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES 'utf8'"));
            $this->pdo->setAttribute (PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            if(php_sapi_name() == 'cli'){
                  $query = $this->pdo->prepare("set session wait_timeout=10000,interactive_timeout=10000,net_read_timeout=10000");
                  $query->execute();
            }
        }
        if(!$select) {
            $success = $this->pdo->exec($sql);
            return $success;
        } else {
            $stmt = $this->pdo->query($sql);
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            return $row;
        }
    }
    function removeWords($string)
    {
        $wordlist = array('/\bcabanas\b/','/\bboutique\b/','/\bresort\b/','/\bcasino\b/','/\bspa\b/','/&/','/\band\b/',
            '/\by\b/','/\bapart\b/','/\bsuites\b/','/\bhotel\b/','/\blodge\b/','/\bhostel\b/','/\bhosteria\b/','/\bapartamentos\b/',
            '/\bdepartamentos\b/','/\brefugio\b/','/\bbungalows\b/','/\bcabana\b/','/\bcasa\b/','/\bprivate\b/');
        return preg_replace($wordlist, '', $string);
    }
    function sortString($string,$sort=false) {
        $string = str_replace(array('.',',','–','-','_','|',';'), ' ', html_entity_decode($string));
        $string = $this->convertAddress($string);
        $array = explode(' ',$this->removeWords(strtolower($string))); 
        $array = array_unique($array);
        if ($sort) sort($array);
        return trim(implode(' ',$array));  
    }
    function encodeURIComponent($str) {
        $revert = array('%21'=>'!', '%2A'=>'*', '%27'=>"'", '%28'=>'(', '%29'=>')');
        return strtr(urlencode($str), $revert);
    }
    function convertAddress($address)
    {
        $normalizeChars = array(
            'Š'=>'S', 'š'=>'s', 'Ð'=>'Dj','Ž'=>'Z', 'ž'=>'z', 'À'=>'A', 'Á'=>'A', 'Â'=>'A', 'Ã'=>'A', 'Ä'=>'A',
            'Å'=>'A', 'Æ'=>'A', 'Ç'=>'C', 'È'=>'E', 'É'=>'E', 'Ê'=>'E', 'Ë'=>'E', 'Ì'=>'I', 'Í'=>'I', 'Î'=>'I',
            'Ï'=>'I', 'Ñ'=>'N', 'Ń'=>'N', 'Ò'=>'O', 'Ó'=>'O', 'Ô'=>'O', 'Õ'=>'O', 'Ö'=>'O', 'Ø'=>'O', 'Ù'=>'U', 'Ú'=>'U',
            'Û'=>'U', 'Ü'=>'U', 'Ý'=>'Y', 'Þ'=>'B', 'ß'=>'Ss','à'=>'a', 'á'=>'a', 'â'=>'a', 'ã'=>'a', 'ä'=>'a',
            'å'=>'a', 'æ'=>'a', 'ç'=>'c', 'è'=>'e', 'é'=>'e', 'ê'=>'e', 'ë'=>'e', 'ì'=>'i', 'í'=>'i', 'î'=>'i',
            'ï'=>'i', 'ð'=>'o', 'ñ'=>'n', 'ń'=>'n', 'ò'=>'o', 'ó'=>'o', 'ô'=>'o', 'õ'=>'o', 'ö'=>'o', 'ø'=>'o', 'ù'=>'u',
            'ú'=>'u', 'û'=>'u', 'ü'=>'u', 'ý'=>'y', 'ý'=>'y', 'þ'=>'b', 'ÿ'=>'y', 'ƒ'=>'f',
            'ă'=>'a', 'î'=>'i', 'â'=>'a', 'ș'=>'s', 'ț'=>'t', 'Ă'=>'A', 'Î'=>'I', 'Â'=>'A', 'Ș'=>'S', 'Ț'=>'T',
        );
        $address = preg_replace("/\([^)]+\)/","",strtr($address, $normalizeChars));
        return strtolower(trim(preg_replace('/[\x00-\x1F\x80-\xFF]/', '',$address)));
    }
    function gLngLat($url, $repeat=true)
    {
        $lat = '';
        $lng = '';
        if(!$this->curl2) $this->curl2 = curl_init();
        curl_setopt($this->curl2, CURLOPT_URL, $url);
        curl_setopt($this->curl2, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($this->curl2, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($this->curl2, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($this->curl2, CURLOPT_CONNECTTIMEOUT, 10);
        $response = curl_exec($this->curl2);
        // curl_close($this->curl2);
        if(!preg_match('%geometry%', $response)) $response = false;
        if(!$repeat) {sleep(2);return $response;}
        $tries = 0;
        while(($tries++<=5) && ($repeat) && (!$response)) {
            $response = $this->gLngLat($url, false);
        }
        if($response) {
            $response_a = json_decode($response);
            if(isset($response_a->results[0])) {
                $lat = $response_a->results[0]->geometry->location->lat;
                $lng = $response_a->results[0]->geometry->location->lng;
            } //else {echo $url."<br>";die;}
        }
        return array($lat,$lng);
    }
    function oLngLat($url, $repeat=true)
    {
        $lat = '';
        $lng = '';
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        $response = curl_exec($ch);
        // curl_close($ch);
        if(!$repeat) return $response;
        $tries = 0;
        while(($repeat) && (!$response)) {
            $tries++;
            if($tries>5) break;
            $response = $this->oLngLat($url, false);
        }
        if($response) {
            $response_a = json_decode($response);
            if(isset($response_a[0])) {
                $lat = $response_a[0]->lat;
                $lng = $response_a[0]->lon;
            } //else {echo $url."<br>";die;}
        }
        return array($lat,$lng);
    }
    function compare_distance($lat1, $lon1, $lat2, $lon2, $margin=5) 
    {
        $theta = $lon1 - $lon2;
        $dist = sin(deg2rad($lat1)) * sin(deg2rad($lat2)) +  cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * cos(deg2rad($theta));
        $dist = acos($dist);
        $dist = rad2deg($dist);
        $miles = $dist * 60 * 1.1515;
        $distance_in_meters = $miles * 1.609344*1000;    
        if($distance_in_meters<=$margin) { 
            return 1;
        } else {
            return 0;
        }
    }
    function parseCsv($file, $city_name)
    {
        $result = array();
        $fp = fopen($file,"r");
        $i=0;
        while(($line=fgetcsv($fp, 0, ','))!==false) {
            if($i++==0) continue;
            // if($i==200) break;
            $row['name'] = htmlspecialchars_decode($line[0]);
            $row['hotel'] = $this->sortString($row['name']);
            $row['sort_hotel'] = $this->sortString($row['name'], true);
            $row['lat'] = '';
            $row['lng'] = '';
            if(isset($line[1])) {
                $address = isset($line[2]) && $line[2] ? $line[1].' '.$line[2] : $line[1];
                if(!preg_match('%\b'.$city_name.'\b%i', $address)) $address .= ' '.$city_name;
                $address = mysql_real_escape_string( $this->convertAddress($address) );
                $db_row = $this->executeQuery("SELECT lat, lng FROM `csv_addresses_tb` WHERE address = '$address'", true);
                if(empty($db_row)) {
                    $latLng = $this->gLngLat('https://maps.google.com/maps/api/geocode/json?address='.$this->encodeURIComponent($address).'&sensor=false');//&key=AIzaSyCuSZe2A_7-LsGcO5lBvzYrCGOHhEjIQrM
                    // $latLng = $this->oLngLat('http://nominatim.openstreetmap.org/search?q='.$this->encodeURIComponent($this->convertAddress($address)).'&format=json&polygon=1&addressdetails=1');
                    $row['lat'] = $latLng[0];
                    $row['lng'] = $latLng[1];
                } else {
                    $row['lat'] = $db_row['lat'];
                    $row['lng'] = $db_row['lng'];
                }
                $result[] =$row;
                if(empty($db_row) && $row['lat'] && $row['lng']) {
                    $sql = "INSERT INTO `csv_addresses_tb` (address, lat, lng) values ('$address','".$row['lat']."','".$row['lng']."');";
                    $success = $this->executeQuery(trim($sql));
                    if(!$success) {
                        $success = $this->executeQuery(trim($sql)); // try again
                        // die("Failed MySql Query: INSERT INTO `csv_addresses_tb` (address, lat, lng) values ('$address','".$row['lat']."','".$row['lng']."');");
                    }
                }
            }
        }
        fclose($fp);
        return $result;
    }
    function scrapeDespegar($url ,$result=array(), $page=1)
    {
        $content = $this->getHTML($url);
        $result = $this->despegar($content);
        while(preg_match('%<li class="next enabled%i', $content)) {
            $page++;
            $content = $this->getHTML(str_replace('/i1/', '/i'.$page.'/', $url));
            $result = $this->despegar($content, $result);
        }
        return $result;
    }

    protected function despegar($content ,$result=array())
    {
        if($content) {
            $html = str_get_html($content);
            foreach ($html->find('div[id="hotelResults"]',0)->children() as $key => $hotel) {
                if($hotel->find('a.hf-rb-hotelName',-1)) {
                    $row = array();
                    $row['name'] = htmlspecialchars_decode(preg_replace('/\s+/', ' ',trim($hotel->find('a.hf-rb-hotelName',0)->title)));
                    $row['hotel'] = $this->sortString($row['name']);
                    $row['sort_hotel'] = $this->sortString($row['name'], true);
                    $row['url'] = 'http://www.despegar.com.ar'.$hotel->find('a.hf-rb-hotelName',0)->href;
                    $id = $hotel->id;
                    if(preg_match('%"id": "'.$id.'",\s*"latitude":(.+?),\s*"longitude":(.+?),%s', $content, $match))
                    {
                        $row['lat'] = $match[1];
                        $row['lng'] = $match[2];
                    } else {
                        $row['lat'] = '';
                        $row['lng'] = '';
                    }
                    $result[] = $row;
                }
            }
        }
        return $result;
    }

    function scrapeWelcomeArgentina($url, $result=array())
    {
        $content = $this->getHTML($url);
        if($content) {
            if(preg_match('%mapdata(.+?)};%s', $content, $match)) {
                $match[0] = preg_replace('%\s+%', ' ', $match[0]);
                $mapdata =  json_decode(str_replace(array('mapdata = ', ';', '\'', ', }'), array('','','"','}'), $match[0]), true);
            }
            $features = $mapdata['features'];
            $html = str_get_html($content);
            $i=0;
            foreach ($html->find('div.fr div.lista') as $key => $hotel) {
                if($hotel->find('a[class="hlink-wel"]',-1)) {
                    $row = array();
                    $row['name'] = trim(htmlspecialchars_decode($hotel->find('a[class="hlink-wel"]',0)->plaintext));
                    $row['hotel'] = $this->sortString($row['name']);
                    $row['sort_hotel'] = $this->sortString($row['name'], true);
                    $url = $hotel->find('a[class="hlink-wel"]',0)->href;
                    if(preg_match('%/includes/redireccion.html\?cliente=%', $url)) {
                        $url = urldecode(str_replace('/includes/redireccion.html?cliente=', '', $url));
                    }
                    $row['url'] = $url;
                    $id = str_replace('c', '', $hotel->id);
                    if($features[$i]['properties']['id']==$id && isset($features[$i]['geometry'])) {
                        $row['lat'] = $features[$i]['geometry']['coordinates'][1];
                        $row['lng'] = $features[$i]['geometry']['coordinates'][0];
                    } else {
                        $row['lat'] = '';
                        $row['lng'] = '';
                    }
                    $result[] = $row;
                    $i++;
                }
            }
        }
        return $result;
    }     
    function scrapeBooking($url ,$result=array(), $page=0)
    {if(file_exists(__DIR__.'/booking.htm')) unlink(__DIR__.'/booking.htm');
        $content = $this->getHTML($url);
        // file_put_contents(__DIR__.'/booking_'.$page.'.htm', $content);
        $result = $this->booking($content);
        $next = true;
        $html = str_get_html($content);
        $offset = 0;
        if(!$html->find('a[class*="paging-next"]',-1)) {
            $next = false;
        } else {
            $url = $html->find('a[class*="paging-next"]',0)->href;
            if(preg_match('%offset=(.+)%', $url, $match)) $offset = $match[1];
        }
        $tries=0;
        while($next) {
            $page++;echo "cpl p:".$page.", ";
            // if($page>=2) break;
            $content = $this->getHTML($url);
            // file_put_contents(__DIR__.'/booking.htm', $offset."\n", FILE_APPEND);
            $html = str_get_html($content);
            if(!$html->find('a[class*="paging-next"]',-1)) {
                $next = false;
            } else {
                $new_url = $html->find('a[class*="paging-next"]',0)->href;
                if(preg_match('%offset=(.+)%', $new_url, $match)) {
                    if($match[1]<$offset) {
                        if($tries++>=3) return $result;
                        continue;
                    } else {
                        $url = $new_url;
                        $offset = $match[1];
                        $tries = 0;
                    }
                } else {
                    if($tries++>=3) return $result;
                    continue;
                }
            }
            $new_result = $this->booking($content, $result);
            if(!empty($new_result)) {
                $result = $new_result;
            }
        }
        return $result;
    }
    protected function booking($content ,$result=array())
    {
        if($content) {
            $html = str_get_html($content);
            foreach ($html->find('h3.sr-hotel__title') as $key => $hotel) {
                $row = array();
                $row['name'] = htmlspecialchars_decode(preg_replace('/\s+/', ' ',trim($hotel->find('a',0)->plaintext)));
                $row['hotel'] = $this->sortString($row['name']);
                $row['sort_hotel'] = $this->sortString($row['name'], true);
                $row['url'] = 'http://www.booking.com'.$hotel->find('a',0)->href;
                $sub_page = $this->getHTML($row['url']);
                $sub_html = str_get_html($sub_page);
                if($sub_html->find('.hp_address_subtitle',-1)) {
                    $row['address'] = trim($sub_html->find('.hp_address_subtitle',0)->plaintext);
                    $address = mysql_real_escape_string($this->convertAddress($row['address']));
                    $db_row = $this->executeQuery("SELECT lat, lng FROM `csv_addresses_tb` WHERE address = '$address'", true);
                    if(empty($db_row)) {
                        $latLng = $this->gLngLat('http://maps.google.com/maps/api/geocode/json?address='.urlencode($this->convertAddress($row['address'])).'&sensor=false');
                        $row['lat'] = $latLng[0];
                        $row['lng'] = $latLng[1];
                        if($row['lat'] && $row['lng']) {
                            $sql = "INSERT INTO `csv_addresses_tb` (address, lat, lng) values ('$address','".$row['lat']."','".$row['lng']."');";
                            $this->executeQuery($sql);
                        }
                    } else {
                        $row['lat'] = $db_row['lat'];
                        $row['lng'] = $db_row['lng'];
                    }
                }
                $result[] = $row;
            }
        }
        return $result;
    }
    function getHTML($url)
    {
        $result = $this->html($url);
        $tries = 0;
        while(($tries++<=2) && (!$result)) {
            // $tries++;
            if($tries>2) break;
            $result = $this->html($url);         
        }
        return $result;
    }
    protected function html($url)
    {
        $ua = "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Safari/537.36";
        if(!$this->curl) $this->curl = curl_init($url); // initialize curl with given url
        curl_setopt($this->curl, CURLOPT_URL, $url);
        curl_setopt($this->curl, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($this->curl, CURLOPT_USERAGENT, $ua); // set  useragent
        curl_setopt($this->curl, CURLOPT_MAXREDIRS, 10 );
        curl_setopt($this->curl, CURLOPT_RETURNTRANSFER, true); // write the response to a variable
        curl_setopt($this->curl, CURLOPT_FOLLOWLOCATION, true); // follow redirects if any
        curl_setopt($this->curl, CURLOPT_CONNECTTIMEOUT, 10); // max. seconds to execute
        curl_setopt($this->curl, CURLOPT_FAILONERROR, 1); // stop when it encounters an error
        $result = curl_exec($this->curl);
        $info = curl_getinfo($this->curl);
        // curl_close($ch);
        return utf8_encode($result);
    }
}
?>