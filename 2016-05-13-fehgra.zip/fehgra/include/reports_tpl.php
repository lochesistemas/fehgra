<div class="col-md-12">
  	<div class="box">
         <div class="box-header">
		 	  <h3 class="box-title">
			     <?php
                $select = mysql_query("SELECT u.typeid typeid, r.id region_id from users u JOIN city c ON c.id=u.sid JOIN region r ON r.id=c.rid  where userid='".$_SESSION['id']."';");
                $result=mysql_fetch_array($select);
                $typeid = $result['typeid'];
                if(!$typeid) $typeid = '1';
                $region_id = $result['region_id'];
                if($typeid=='3') {
                  $select=mysql_query("SELECT s.query_id,s.no_legal_hotels,s.no_illegal_hotels,uf.source as source,u.name as username, c.name as city_name FROM `summary_hotel_results_tb` s JOIN userfiles uf ON s.query_id=uf.query_id JOIN users u ON u.userid=uf.uid JOIN city c ON c.id=uf.city_id where uf.uid='".$_SESSION['id']."'");
                } elseif($typeid=='2') {
                  $select=mysql_query("SELECT s.query_id,s.no_legal_hotels,s.no_illegal_hotels,uf.source as source,u.name as username, c.name as city_name FROM `summary_hotel_results_tb` s JOIN userfiles uf ON s.query_id=uf.query_id JOIN users u ON u.userid=uf.uid JOIN city c ON c.id=uf.city_id where c.rid='$region_id'");
                } else {
                  $select=mysql_query("SELECT s.query_id,s.no_legal_hotels,s.no_illegal_hotels,uf.source as source ,u.name as username, c.name as city_name FROM `summary_hotel_results_tb` s JOIN userfiles uf ON s.query_id=uf.query_id JOIN users u ON u.userid=uf.uid JOIN city c ON c.id=uf.city_id");
                }
                if(mysql_num_rows($select)==0) {
            ?>
                <p class="text-red" style="font-size:18px; font-family:Verdana, Arial, Helvetica, sans-serif;"><?php echo "No se han encontrado resultados";?></p>
            <?php }?>
			  </h3>
         </div><!-- /.box-header -->
         <div class="box-body">
		 <?php 
					if(mysql_num_rows($select)>0){
		 ?>
             <table id="example3" class="table table-bordered table-striped" width="100%">
                  <thead>
                  <tr>
                       
                       <th>Fecha</th>
                       <?php if($typeid=='1' || $typeid=='2'): ?>
                         <th>Usuario</th>
                         <th>Origen</th>
                         <th>Ciudad</th>
                       <?php endif; ?>
                       <th>Alojamientos Formales</th>
		                    <th>Alojamientos Informales</th>
                       
                       
                        <th style="width: 40px">Accion</th>
                  </tr>
                  </thead>
                  <tbody>
                <?php 
                $counter=1;
                    while($result=mysql_fetch_array($select)){
                ?>
                  <tr>
                        <td><?php echo $result["query_id"];?></td>
                        <?php if($typeid=='1' || $typeid=='2'): ?>
                        <td><?php echo $result["username"];?></td>
                        <td><?php echo $result["source"];?></td>
                        <td><?php echo $result["city_name"];?></td>
                        <?php endif; ?>       
                        <td><?php echo $result["no_legal_hotels"];?></td>
                        <td><?php echo $result["no_illegal_hotels"];?></td>

       
                        
                         <td>
                          <a class="btn btn-block btn-primary btn-sm" href="reports.php?query_id=<?php echo strtotime($result["query_id"]);?>">Ver</a>
                         </td>
                         </tr>
                        <?php $counter++;}?>
                 </tbody>
            </table>
        <?php }?>
      	</div></div>
</div>		  
		        