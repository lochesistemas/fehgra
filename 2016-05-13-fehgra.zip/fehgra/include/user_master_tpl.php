<div class="col-md-12">
  	<div class="box">
         <div class="box-header">
		 	<?php if(isset($_GET['msg'])){
				$msg=$_GET['msg'];?>
				<p class="text-green" style="font-size:18px; font-family:Verdana, Arial, Helvetica, sans-serif;"><?php echo "Borrado";?></p>
		 	<?php }?>
              <h3 class="box-title">
			  <a href="user_add.php" id="add" name="add" type="submit" class="btn btn-block btn-primary btn-sm">NUEVO
			  </a>
			  </h3>
         </div><!-- /.box-header -->
         <div class="box-body">
		 <?php 
				$select=mysql_query("SELECT * FROM `users` left join usertype on users.typeid = usertype.typeid ORDER BY userid desc");
					if(mysql_num_rows($select)>0){
		 ?>
        <table id="example1" class="table table-bordered table-striped">
              <thead>
			  <tr>
                   <th style="width: 10px">#</th>
                   <th>usuario</th>
				   <th>Tipo</th>
				   <th>Email</th>
                   <th  colspan="2"style="width: 40px">Acciones</th>
              </tr>
			  </thead>
			  <tbody>
			<?php 
			$counter=1;
				while($result=mysql_fetch_array($select)){
			?>
              <tr>
                    <td><?php echo $counter;?></td>
                    <td><?php echo $result["name"];?></td>
					<td><?php echo $result["type"];?></td>
					<td><?php echo $result["email"];?></td>
                    <td>
                       <a class="btn btn-block btn-warning btn-xs" href="user_add.php?eid=<?php echo $result["userid"];?>">Editar</a> 
                     </td>
					 <td>
					  <a class="btn btn-block btn-danger btn-xs" onclick="return delete_category();" href="user_master.php?did=<?php echo $result["userid"];?>">Eliminar</a>
                     </td>
					 </tr>
					<?php $counter++;}?>
             </tbody>
	 	</table>
				  <?php }?>
      	</div><!-- /.box-body -->
            <!--<div class="box-footer clearfix">
                  <ul class="pagination pagination-sm no-margin pull-right">
                    <li><a href="#">�</a></li>
                    <li><a href="#">1</a></li>
                    <li><a href="#">2</a></li>
                    <li><a href="#">3</a></li>
                    <li><a href="#">�</a></li>
                  </ul>
             </div>-->
	</div>
</div>		  
		        
