<div class="col-md-12">
    <div class="box">
         <div class="box-header">
            <?php $query_id = date('Y-m-d H:i:s', $_GET['query_id']);
                $select = mysql_query("SELECT url,hotel_name,c.name as city_name, r.name as region_name FROM `illegal_hotel_results_tb` as i JOIN `web_hotels_tb` as h ON i.web_hotel_id=h.id JOIN `region` as r ON h.region_id=r.id JOIN `city` as c ON h.city_id=c.id where i.query_id='$query_id'");
                if(mysql_num_rows($select)==0) {
            ?>
                <p class="text-red" style="font-size:18px; font-family:Verdana, Arial, Helvetica, sans-serif;"><?php echo "No se encontraron registros";?></p>
            <?php }?>
              
         </div><!-- /.box-header -->
         <div class="box-body">
<?php
    if(isset($_GET['query_id'])) {
        
        if(mysql_num_rows($select)>0){ ?>
        <table id="example4" class="table table-bordered table-striped" width="100%">
              <thead>
              <tr>
                   <th style="width: 50%">Establecimiento</th>
                   <th style="width: 20%">Ciudad</th>
                   <th style="width: 20%">Region</th>
                   <th style="width: 10%">Direccion Web</th>
                   <th style="width: 10%">Direccion Web</th>
              </tr>
              </thead>
              <tbody>
            <?php 
            $counter=1;
                while($result=mysql_fetch_array($select)){
            ?>
               <tr>
                    
                    <td><?php echo $result["hotel_name"];?></td>
                    
                    <td><?php echo $result["city_name"];?></td>
                    <td><?php echo $result["region_name"];?></td>
                    <td><?php echo $result["url"];?></td>
                    <td><a class="btn btn-block btn-primary btn-sm" href="<?php echo $result["url"];?>" target="_blank">Ver</a></td>
                </tr>
                    <?php $counter++;}?>
             </tbody>
        </table>
        <?php }
    }
?>
        </div>
    </div>
</div>  