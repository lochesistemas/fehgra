<?php include("include/list_of_js/admin_js1.js")?>
<?php
ini_set("display_errors",E_DEPRECATED);
$name=$email=$password="";
if(isset($_POST['submit'])){
	$name=$_POST['username'];
	$email=$_POST['email'];
	$password=$_POST['password'];
	//echo "update `admin` set `username`='".$name."'  `password`='".$password."' `emailid`='".$email."' where id='1' ";exit();
$db_insert=mysql_query("update `users` set `name`='".$name."', `password`='".$password."' , `email`='".$email."' where userid='".$_SESSION['id']."' ");
}
$select_query = mysql_query("select * from users where userid='".$_SESSION['id']."' ");
$data_query = mysql_fetch_array($select_query);
?>
<div class="col-md-6">
		<div class="box box-primary">
                <div class="box-header">
                  <h3 class="box-title"></h3>
                </div><!-- /.box-header -->
                <!-- form start -->
				<p id="head"></p>
                <form role="form" method="post" name="form" action="">
                  <div class="box-body">
				  	<div class="form-group">
                      <label for="userName">Usuario</label>
                      <input type="text" class="form-control" name="username" id="username" value="<?php echo $data_query['name'];?>" placeholder="<?php echo $data_query['name'];?>"><p id="p1" class="text-red"></p>
                    </div>
					<div class="form-group">
                      <label for="password">Contrase&ntilde;a</label>
                      <input type="password" class="form-control" name="password" id="password" value="<?php echo $data_query['password'];?>" placeholder="<?php echo $data_query['password'];?>"><p id="p2" class="text-red"></p>
                    </div>
					<div class="form-group">
                      <label for="confirmPassword">Confirmacion</label>
                      <input type="password" class="form-control" name="cpassword" id="cpassword" placeholder="Repita la contrase&ntilde;a"><p id="p3" class="text-red"></p>
                    </div>
                    <div class="form-group">
                      <label for="exampleInputEmail1">Email</label>
                      <input type="email" class="form-control" name="email" id="email" value="<?php echo $data_query['email'];?>" placeholder="<?php echo $data_query['email'];?>"><p id="p4" class="text-red"></p>
                    </div>
                  </div><!-- /.box-body -->

                  <div class="box-footer">
                    <input id="submit" type="submit" name="submit" class="btn btn-primary"></button>
                  </div>
                </form>
     </div>
</div>