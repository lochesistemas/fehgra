<?php include("include/list_of_js/admin_js1.js")?>
<?php
ini_set("display_errors",E_DEPRECATED);
?>
<div class="col-md-12">
		<div class="box box-primary">
                <div class="box-header">
                  <h3 class="box-title"></h3>
                </div><!-- /.box-header -->
                <!-- form start -->
				<p id="head"></p>
                <form role="form" method="post" name="form" action="">
                  <div class="box-body">
<h1>BIENVENIDO</h1></br>
<p align="justify">A la Plataforma de Identificaci&oacute;n de Oferta Informal desarrollada por el Departamento de Actividades Informales de la FEHGRA. La presente herramienta se encuentra destinada a realizar comprobaciones autom&aacute;ticas entre distintos sitios web de oferta tur&iacute;stica (Booking.com, Despegar.com, InterPatagonia.com.ar y WelcomeArgentina.com) y los listados oficiales de establecimientos provistos por las distintas entidades gubernamentales y reguladoras de cada localidad con el objetivo de ayudar a detectar la oferta informal de alojamientos en internet.

<h2>C&oacute;mo se utiliza?</h2>
<p align="justify">Desde la secci&oacute;n <em>Realizar análisis</em> disponible en el men&uacute; lateral derecho, usted podr&aacute; comenzar a utilizar la plataforma. Para ello deber&aacute; completar tres simples pasos.
1) Importar el listado de alojamientos registrados provisto por el organismo de control de su localidad en el formato de archivo que indique la plataforma. 
2) Ingresar la direcci&oacute;n web del sitio web compatible con el cual desea realizar la comprobaci&oacute;n siguiendo las indicaciones de la herramienta.
3) Indicar el organismo responsable del listado de alojamientos registrados y ejecutar el an&aacute;lisis.</p>
</p>


                  </div><!-- /.box-body -->

                  
                
     </div>
</div>